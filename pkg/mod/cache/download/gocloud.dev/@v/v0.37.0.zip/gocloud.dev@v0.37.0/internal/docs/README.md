# Docs

This is the documentation for developers of the Go CDK, describing various
coding practices and project processes.

-   [Design Decisions](design.md)
-   [Releases](release.md)
