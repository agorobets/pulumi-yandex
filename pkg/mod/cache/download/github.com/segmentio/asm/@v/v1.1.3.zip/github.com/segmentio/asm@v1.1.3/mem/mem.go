package mem

import _ "github.com/segmentio/asm/cpu"
