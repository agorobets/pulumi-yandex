package contract

// Explicitly ignore an error returned from IO.
func IgnoreIoError(_ int, _ error) {}
