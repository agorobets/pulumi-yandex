package version

// Version is the version of this tool.
var Version string
