# pulumi/pkg

While pulumi/sdk maintains strict backwards compatibility guarantees, code under pkg/ is handled more
informally: while breaking changes are still discouraged they may happen when they make sense.
