// Copyright 2020-2024, Pulumi Corporation.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package diy

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"

	"gocloud.dev/blob"
)

func mustNotHaveError(t *testing.T, context string, err error) {
	t.Helper()
	if err != nil {
		t.Fatalf("Error in testcase %q, aborting: %v", context, err)
	}
}

// The wrappedBucket type exists so that when we use the blob.Bucket type we can present a consistent
// view of file paths. Since it will assume that backslashes (file separators on Windows) are part of
// file names, and this causes "problems".
func TestWrappedBucket(t *testing.T) {
	t.Parallel()

	// wrappedBucket will only massage file paths IFF it is needed, as filepath.ToSlash is a noop.
	if filepath.Separator == '/' {
		assert.Equal(t, `foo\bar\baz`, filepath.ToSlash(`foo\bar\baz`))
		t.Skip("Skipping wrappedBucket tests because file paths won't be modified.")
	}

	// Initialize a diy backend, using the default Pulumi directory.
	cloudURL := FilePathPrefix + "~"
	ctx := context.Background()
	b, err := New(ctx, nil, cloudURL, nil)
	if err != nil {
		t.Fatalf("Initializing new diy backend: %v", err)
	}
	diyBackend, ok := b.(*diyBackend)
	if !ok {
		t.Fatalf("backend wasn't of type diyBackend?")
	}

	wrappedBucket, ok := diyBackend.bucket.(*wrappedBucket)
	if !ok {
		t.Fatalf("diyBackend.bucket wasn't of type wrappedBucket?")
	}

	// Perform basic file operations using wrappedBucket and verify that it will
	// successfully handle both "/" and "\" as file separators. (And probably fail in
	// exciting ways if you try to give it a file on a system that supports "\" or "/" as
	// a valid character in a filename.)
	//nolint:paralleltest // uses shared state with parent
	t.Run("SanityCheck", func(t *testing.T) {
		randomData := []byte("Just some random data")

		err := wrappedBucket.WriteAll(ctx, ".pulumi/bucket-test/foo", randomData, &blob.WriterOptions{})
		mustNotHaveError(t, "WriteAll", err)

		readData, err := wrappedBucket.ReadAll(ctx, `.pulumi\bucket-test\foo`)
		mustNotHaveError(t, "ReadAll", err)
		assert.EqualValues(t, randomData, readData, "data read from bucket doesn't match what was written")

		// Verify the leading slash isn't necessary.
		err = wrappedBucket.Delete(ctx, ".pulumi/bucket-test/foo")
		mustNotHaveError(t, "Delete", err)

		exists, err := wrappedBucket.Exists(ctx, ".pulumi/bucket-test/foo")
		mustNotHaveError(t, "Exists", err)
		assert.False(t, exists, "Deleted file still found?")
	})

	// Verify ListObjects / listBucket works with regard to differeing file separators too.
	//nolint:paralleltest // uses shared state with parent
	t.Run("ListObjects", func(t *testing.T) {
		randomData := []byte("Just some random data")
		filenames := []string{"a.json", "b.json", "c.json"}

		// Write some data.
		for _, filename := range filenames {
			key := ".pulumi\\bucket-test\\" + filename
			err := wrappedBucket.WriteAll(ctx, key, randomData, &blob.WriterOptions{})
			mustNotHaveError(t, "WriteAll", err)
		}

		// Verify it is found. NOTE: This requires that any files created
		// during other tests have successfully been cleaned up too.
		objects, err := listBucket(ctx, wrappedBucket, `.pulumi\bucket-test`)
		mustNotHaveError(t, "listBucket", err)
		if len(objects) != len(filenames) {
			assert.Equal(t, 3, len(objects), "listBucket returned unexpected number of objects.")
			for _, object := range objects {
				t.Logf("Got object: %+v", object)
			}
		}
	})
}
