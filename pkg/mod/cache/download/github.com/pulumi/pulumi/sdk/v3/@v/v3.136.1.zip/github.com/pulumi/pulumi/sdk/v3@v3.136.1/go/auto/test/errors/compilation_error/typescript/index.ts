import * as pulumi from "@pulumi/pulumi";

will not compile
