"""A Python Pulumi program"""

import pulumi

lst = []
lst[0]
