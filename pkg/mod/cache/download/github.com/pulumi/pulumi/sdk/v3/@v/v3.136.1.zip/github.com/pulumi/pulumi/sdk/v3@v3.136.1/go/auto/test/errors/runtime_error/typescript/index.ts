import * as pulumi from "@pulumi/pulumi";

let x: any = null;
x.foo = "abc";
