"use strict";
const pulumi = require("@pulumi/pulumi");

var x = null;
x.foo = "abc";
