using Pulumi;

class MyStack : Stack
{
    public MyStack()
    {
        // Add your resources here
        will not compile
    }
}
