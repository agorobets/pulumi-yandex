// Copyright 2023, Pulumi Corporation.

package version

// Version is initialized by the Go linker to contain the semver of this build.
var Version string
