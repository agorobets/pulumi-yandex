// Copyright 2021, Pulumi Corporation.

// Package client implements a client for the Pulumi Service HTTP/REST API.
// Important note: This client is not versioned, and not intended for external use at this time.
package client
