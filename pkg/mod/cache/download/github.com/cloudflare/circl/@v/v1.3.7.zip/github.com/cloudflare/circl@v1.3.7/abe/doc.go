// Package abe provides Attribute-based data encryption algorithms.
package abe
