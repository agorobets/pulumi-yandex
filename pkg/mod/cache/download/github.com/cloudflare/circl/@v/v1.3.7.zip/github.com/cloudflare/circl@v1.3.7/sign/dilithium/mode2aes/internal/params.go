// Code generated from params.templ.go. DO NOT EDIT.

package internal

const (
	Name          = "Dilithium2-AES"
	UseAES        = true
	K             = 4
	L             = 4
	Eta           = 2
	DoubleEtaBits = 3
	Omega         = 80
	Tau           = 39
	Gamma1Bits    = 17
	Gamma2        = 95232
)
