// Package cpabe provides Ciphertext-Policy Attribute-based Encryption algorithms.
package cpabe
