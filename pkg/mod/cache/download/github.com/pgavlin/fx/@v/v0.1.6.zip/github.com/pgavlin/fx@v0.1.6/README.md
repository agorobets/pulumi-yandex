# `fx`: Functional utilities for Go

<a href="https://godoc.org/github.com/pgavlin/fx"><img src="https://img.shields.io/badge/api-reference-blue.svg?style=flat-square" alt="GoDoc"></a>
