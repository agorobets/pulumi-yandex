# Changes

## [0.169.0](https://github.com/googleapis/google-api-go-client/compare/v0.168.0...v0.169.0) (2024-03-07)


### Features

* **all:** Auto-regenerate discovery clients ([#2450](https://github.com/googleapis/google-api-go-client/issues/2450)) ([d22da18](https://github.com/googleapis/google-api-go-client/commit/d22da1806db891da12d7290ef4334e18fbaf0ca2))
* **all:** Auto-regenerate discovery clients ([#2454](https://github.com/googleapis/google-api-go-client/issues/2454)) ([2675c0a](https://github.com/googleapis/google-api-go-client/commit/2675c0abf9e442bb3ac35e18ecc196aaaa4facd3))
* **all:** Auto-regenerate discovery clients ([#2457](https://github.com/googleapis/google-api-go-client/issues/2457)) ([a488112](https://github.com/googleapis/google-api-go-client/commit/a488112cd111b883dfaffa7e4ab67e99a6ea9b90))

## [0.168.0](https://github.com/googleapis/google-api-go-client/compare/v0.167.0...v0.168.0) (2024-03-04)


### Features

* **all:** Auto-regenerate discovery clients ([#2431](https://github.com/googleapis/google-api-go-client/issues/2431)) ([e635a5e](https://github.com/googleapis/google-api-go-client/commit/e635a5e61572ec4a7dbad19a9e32ab7918cde9f0))
* **all:** Auto-regenerate discovery clients ([#2433](https://github.com/googleapis/google-api-go-client/issues/2433)) ([0c30ecc](https://github.com/googleapis/google-api-go-client/commit/0c30ecca06ff770fafce74743b0a038122e31813))
* **all:** Auto-regenerate discovery clients ([#2436](https://github.com/googleapis/google-api-go-client/issues/2436)) ([4dc71d4](https://github.com/googleapis/google-api-go-client/commit/4dc71d4531deeb116af23cd13245ca644f0be991))
* **all:** Auto-regenerate discovery clients ([#2438](https://github.com/googleapis/google-api-go-client/issues/2438)) ([d290e18](https://github.com/googleapis/google-api-go-client/commit/d290e1861655087f52294c6e4994688cbfb3098a))
* **all:** Auto-regenerate discovery clients ([#2442](https://github.com/googleapis/google-api-go-client/issues/2442)) ([9f9c0cf](https://github.com/googleapis/google-api-go-client/commit/9f9c0cf59e864281bd8b04319e4ce4c3914e147c))
* **all:** Auto-regenerate discovery clients ([#2443](https://github.com/googleapis/google-api-go-client/issues/2443)) ([ced0c09](https://github.com/googleapis/google-api-go-client/commit/ced0c099be7b1bfa2802567f2a6e57b69b29285e))
* **all:** Auto-regenerate discovery clients ([#2445](https://github.com/googleapis/google-api-go-client/issues/2445)) ([4fa90c9](https://github.com/googleapis/google-api-go-client/commit/4fa90c93dd04c64c6e1a35b358a23cb014be0e7a))
* **all:** Auto-regenerate discovery clients ([#2447](https://github.com/googleapis/google-api-go-client/issues/2447)) ([022c85c](https://github.com/googleapis/google-api-go-client/commit/022c85c3d443e58228ea3eb51ee621f2a20d3a45))
* **all:** Auto-regenerate discovery clients ([#2448](https://github.com/googleapis/google-api-go-client/issues/2448)) ([af383c7](https://github.com/googleapis/google-api-go-client/commit/af383c78468f5129b2333ad7222fb361873a4cd4))
* **all:** Auto-regenerate discovery clients ([#2449](https://github.com/googleapis/google-api-go-client/issues/2449)) ([b438981](https://github.com/googleapis/google-api-go-client/commit/b43898129eca3b710c3573c48672b73a46ea9cdc))

## [0.167.0](https://github.com/googleapis/google-api-go-client/compare/v0.166.0...v0.167.0) (2024-02-23)


### Features

* **all:** Auto-regenerate discovery clients ([#2427](https://github.com/googleapis/google-api-go-client/issues/2427)) ([f72b5af](https://github.com/googleapis/google-api-go-client/commit/f72b5af5b412eec03394457a27065e58ae6d7f43))
* **all:** Auto-regenerate discovery clients ([#2429](https://github.com/googleapis/google-api-go-client/issues/2429)) ([55a9e5a](https://github.com/googleapis/google-api-go-client/commit/55a9e5a4be3360d0294c3811503e83c694ed8d28))

## [0.166.0](https://github.com/googleapis/google-api-go-client/compare/v0.165.0...v0.166.0) (2024-02-21)


### Features

* **all:** Auto-regenerate discovery clients ([#2417](https://github.com/googleapis/google-api-go-client/issues/2417)) ([260fc1e](https://github.com/googleapis/google-api-go-client/commit/260fc1ef78c67de11cc5d654fcbe08edd8c01843))
* **all:** Auto-regenerate discovery clients ([#2419](https://github.com/googleapis/google-api-go-client/issues/2419)) ([c969083](https://github.com/googleapis/google-api-go-client/commit/c96908374e9b394e34b94768e006100b1a48ab4c))
* **all:** Auto-regenerate discovery clients ([#2420](https://github.com/googleapis/google-api-go-client/issues/2420)) ([762eb61](https://github.com/googleapis/google-api-go-client/commit/762eb619b72aa10d7b177398df86c53a3ac4e9f0))
* **all:** Auto-regenerate discovery clients ([#2421](https://github.com/googleapis/google-api-go-client/issues/2421)) ([af6aa38](https://github.com/googleapis/google-api-go-client/commit/af6aa38b90461f3a5d1bfe13a86aa788f4b08da1))
* **all:** Auto-regenerate discovery clients ([#2424](https://github.com/googleapis/google-api-go-client/issues/2424)) ([b3f9c38](https://github.com/googleapis/google-api-go-client/commit/b3f9c38b88e452ef2c90a7cd1bf09be9d4b2cdbd))
* **all:** Auto-regenerate discovery clients ([#2425](https://github.com/googleapis/google-api-go-client/issues/2425)) ([124a535](https://github.com/googleapis/google-api-go-client/commit/124a535e30e079b1b0f240ebbd5a638e7207f275))
* **all:** Auto-regenerate discovery clients ([#2426](https://github.com/googleapis/google-api-go-client/issues/2426)) ([446a6bd](https://github.com/googleapis/google-api-go-client/commit/446a6bdd35dfe3d1f32035787065c8ada6003bcf))

## [0.165.0](https://github.com/googleapis/google-api-go-client/compare/v0.164.0...v0.165.0) (2024-02-14)


### Features

* **all:** Auto-regenerate discovery clients ([#2414](https://github.com/googleapis/google-api-go-client/issues/2414)) ([c702880](https://github.com/googleapis/google-api-go-client/commit/c70288098ef2b86e7080b4a4d48056dcc3a50767))
* **all:** Auto-regenerate discovery clients ([#2416](https://github.com/googleapis/google-api-go-client/issues/2416)) ([deab77d](https://github.com/googleapis/google-api-go-client/commit/deab77d12e3f31ede07038325b92cea599607615))

## [0.164.0](https://github.com/googleapis/google-api-go-client/compare/v0.163.0...v0.164.0) (2024-02-12)


### Features

* **all:** Auto-regenerate discovery clients ([#2406](https://github.com/googleapis/google-api-go-client/issues/2406)) ([1bd8304](https://github.com/googleapis/google-api-go-client/commit/1bd8304e017d5aaced1a535580738249da71bcb9))
* **all:** Auto-regenerate discovery clients ([#2408](https://github.com/googleapis/google-api-go-client/issues/2408)) ([f1b37df](https://github.com/googleapis/google-api-go-client/commit/f1b37df9d4f6d3dc1e0dec4ff03427424b6a7cc9))
* **all:** Auto-regenerate discovery clients ([#2409](https://github.com/googleapis/google-api-go-client/issues/2409)) ([246b19f](https://github.com/googleapis/google-api-go-client/commit/246b19f13b64b614d8ca8c049ee88b4d534a57c3))
* **all:** Auto-regenerate discovery clients ([#2412](https://github.com/googleapis/google-api-go-client/issues/2412)) ([51d5068](https://github.com/googleapis/google-api-go-client/commit/51d5068358085484a187cd8a8881d1741139e8fb))


### Bug Fixes

* **transport:** Disable universe domain check if token source ([#2413](https://github.com/googleapis/google-api-go-client/issues/2413)) ([edbe996](https://github.com/googleapis/google-api-go-client/commit/edbe996fdb838db06a84e532b756b3a8342c352a))

## [0.163.0](https://github.com/googleapis/google-api-go-client/compare/v0.162.0...v0.163.0) (2024-02-08)


### Features

* **all:** Auto-regenerate discovery clients ([#2401](https://github.com/googleapis/google-api-go-client/issues/2401)) ([62ceaad](https://github.com/googleapis/google-api-go-client/commit/62ceaad2ceec932061195d173a3e1cef74e5c0bf))
* **all:** Auto-regenerate discovery clients ([#2403](https://github.com/googleapis/google-api-go-client/issues/2403)) ([47834b5](https://github.com/googleapis/google-api-go-client/commit/47834b5efcbfcd8d3e701553b0a1762c3dc414fd))
* **all:** Auto-regenerate discovery clients ([#2405](https://github.com/googleapis/google-api-go-client/issues/2405)) ([2271ef7](https://github.com/googleapis/google-api-go-client/commit/2271ef712ec08f45d9973f543bfbf9243dc6e436))

## [0.162.0](https://github.com/googleapis/google-api-go-client/compare/v0.161.0...v0.162.0) (2024-02-05)


### Features

* **all:** Auto-regenerate discovery clients ([#2388](https://github.com/googleapis/google-api-go-client/issues/2388)) ([f2f2d22](https://github.com/googleapis/google-api-go-client/commit/f2f2d22cf7dc6904306ca941ef8c6994a573a383))
* **all:** Auto-regenerate discovery clients ([#2391](https://github.com/googleapis/google-api-go-client/issues/2391)) ([c8e77f6](https://github.com/googleapis/google-api-go-client/commit/c8e77f698e25db69b2f41997eaddc2ffe1c67d03))
* **all:** Auto-regenerate discovery clients ([#2392](https://github.com/googleapis/google-api-go-client/issues/2392)) ([e5a7a15](https://github.com/googleapis/google-api-go-client/commit/e5a7a1541d287038778a37a22478ac4830cefc17))
* **all:** Auto-regenerate discovery clients ([#2394](https://github.com/googleapis/google-api-go-client/issues/2394)) ([140fb54](https://github.com/googleapis/google-api-go-client/commit/140fb54417a8198f9cc75a25e743836dcf75e171))
* **all:** Auto-regenerate discovery clients ([#2395](https://github.com/googleapis/google-api-go-client/issues/2395)) ([169ead6](https://github.com/googleapis/google-api-go-client/commit/169ead6b4f2336c2b0805a1d60aa8f3aca4d6315))
* **all:** Auto-regenerate discovery clients ([#2398](https://github.com/googleapis/google-api-go-client/issues/2398)) ([eddfeb9](https://github.com/googleapis/google-api-go-client/commit/eddfeb9353a18fd2c8d69fe224bb556f7f17253b))


### Bug Fixes

* **transport:** Enforce 1s timeout on requests to MDS universe_domain ([#2393](https://github.com/googleapis/google-api-go-client/issues/2393)) ([6862015](https://github.com/googleapis/google-api-go-client/commit/6862015b9f6c07ddb74cd2e9fb8d94703b0d42b3))

## [0.161.0](https://github.com/googleapis/google-api-go-client/compare/v0.160.0...v0.161.0) (2024-01-30)


### Features

* **all:** Auto-regenerate discovery clients ([#2386](https://github.com/googleapis/google-api-go-client/issues/2386)) ([03042ec](https://github.com/googleapis/google-api-go-client/commit/03042ec3c59aee67bc19c0c4749d94c41aea21fe))


### Bug Fixes

* **gen:** Reject repeated object query params ([#2383](https://github.com/googleapis/google-api-go-client/issues/2383)) ([f29f327](https://github.com/googleapis/google-api-go-client/commit/f29f32764830b4ef0beaf3c8dcb5af0a02798146)), refs [#2379](https://github.com/googleapis/google-api-go-client/issues/2379)
* **transport:** Skip s2a for now if service has direct path enabled ([#2385](https://github.com/googleapis/google-api-go-client/issues/2385)) ([54c764a](https://github.com/googleapis/google-api-go-client/commit/54c764a3f7f409b13a6ed115576d9b1a5c390972))

## [0.160.0](https://github.com/googleapis/google-api-go-client/compare/v0.159.0...v0.160.0) (2024-01-29)


### Features

* **all:** Auto-regenerate discovery clients ([#2380](https://github.com/googleapis/google-api-go-client/issues/2380)) ([8f26f51](https://github.com/googleapis/google-api-go-client/commit/8f26f5108f1df3cf24e596ccca23f3aae9d34c5d))
* **all:** Auto-regenerate discovery clients ([#2382](https://github.com/googleapis/google-api-go-client/issues/2382)) ([5534cf2](https://github.com/googleapis/google-api-go-client/commit/5534cf22608997ed1fcf1cb88924d34eb5ba0e9a))
* **all:** Auto-regenerate discovery clients ([#2384](https://github.com/googleapis/google-api-go-client/issues/2384)) ([fee4c8f](https://github.com/googleapis/google-api-go-client/commit/fee4c8fd7ec76f90a5818e713fca44213fff732c))

## [0.159.0](https://github.com/googleapis/google-api-go-client/compare/v0.158.0...v0.159.0) (2024-01-26)


### Features

* **all:** Auto-regenerate discovery clients ([#2377](https://github.com/googleapis/google-api-go-client/issues/2377)) ([a8d9414](https://github.com/googleapis/google-api-go-client/commit/a8d941461d22e8ef16843883e66afe33f5605553))


### Bug Fixes

* **transport:** Relax universe checks ([#2376](https://github.com/googleapis/google-api-go-client/issues/2376)) ([55b0516](https://github.com/googleapis/google-api-go-client/commit/55b0516fab1d2c2b3e508b310ec98c9691ad161c))

## [0.158.0](https://github.com/googleapis/google-api-go-client/compare/v0.157.0...v0.158.0) (2024-01-25)


### Features

* **all:** Auto-regenerate discovery clients ([#2361](https://github.com/googleapis/google-api-go-client/issues/2361)) ([6c3b622](https://github.com/googleapis/google-api-go-client/commit/6c3b622e2a358e940307026b3b10ed25f825b5d2))
* **all:** Auto-regenerate discovery clients ([#2365](https://github.com/googleapis/google-api-go-client/issues/2365)) ([f40db7f](https://github.com/googleapis/google-api-go-client/commit/f40db7f9a7ae2dd4a1945c236f5ff792901ed67b))
* **all:** Auto-regenerate discovery clients ([#2366](https://github.com/googleapis/google-api-go-client/issues/2366)) ([e0db6a5](https://github.com/googleapis/google-api-go-client/commit/e0db6a56333968b548ede1aafe64ca58953db492))
* **all:** Auto-regenerate discovery clients ([#2369](https://github.com/googleapis/google-api-go-client/issues/2369)) ([45c097f](https://github.com/googleapis/google-api-go-client/commit/45c097f28a29428d00c4bfb9baee6ac19429e9ee))
* **all:** Auto-regenerate discovery clients ([#2372](https://github.com/googleapis/google-api-go-client/issues/2372)) ([2d69d97](https://github.com/googleapis/google-api-go-client/commit/2d69d972d4c8a20e9247bfcb12beafe38416075a))
* **all:** Auto-regenerate discovery clients ([#2374](https://github.com/googleapis/google-api-go-client/issues/2374)) ([d266978](https://github.com/googleapis/google-api-go-client/commit/d2669784ef23e304318cc449fd578b22c508c0a8))
* **impersonate:** Add universe domain support ([#2296](https://github.com/googleapis/google-api-go-client/issues/2296)) ([6ef1144](https://github.com/googleapis/google-api-go-client/commit/6ef1144a79d93982b56c81cf0116965a7c0bf93a))
* **transport:** Add universe domain support ([#2355](https://github.com/googleapis/google-api-go-client/issues/2355)) ([69626e3](https://github.com/googleapis/google-api-go-client/commit/69626e37973a7f1e7974d7dd0e6e0fee3c0ebe6f))


### Bug Fixes

* **internal:** Support internaloption.WithDefaultUniverseDomain ([#2373](https://github.com/googleapis/google-api-go-client/issues/2373)) ([b21a1fa](https://github.com/googleapis/google-api-go-client/commit/b21a1fa29bb072f7063dfe6e2fe81ac7b8bb5932))
* **transport/grpc:** Add universe domain verification ([#2375](https://github.com/googleapis/google-api-go-client/issues/2375)) ([df17254](https://github.com/googleapis/google-api-go-client/commit/df1725443e664d0bb3985ce05cad40535122bcff))
* **transport:** Not enable s2a when there is endpoint override ([#2368](https://github.com/googleapis/google-api-go-client/issues/2368)) ([73fc7fd](https://github.com/googleapis/google-api-go-client/commit/73fc7fd7fafe625f8c2efb621ff852289a5b5a06))

## [0.157.0](https://github.com/googleapis/google-api-go-client/compare/v0.156.0...v0.157.0) (2024-01-18)


### Features

* **all:** Auto-regenerate discovery clients ([#2345](https://github.com/googleapis/google-api-go-client/issues/2345)) ([c3e43a1](https://github.com/googleapis/google-api-go-client/commit/c3e43a173ab604da8056591a7c2ead184fad22c9))
* **all:** Auto-regenerate discovery clients ([#2348](https://github.com/googleapis/google-api-go-client/issues/2348)) ([763c331](https://github.com/googleapis/google-api-go-client/commit/763c331a70ada0912c1557e7160f1c3b09bf8172))
* **all:** Auto-regenerate discovery clients ([#2349](https://github.com/googleapis/google-api-go-client/issues/2349)) ([3bf8f4f](https://github.com/googleapis/google-api-go-client/commit/3bf8f4fde158ed60fd365622cc95a6cfea3d8c0a))
* **all:** Auto-regenerate discovery clients ([#2352](https://github.com/googleapis/google-api-go-client/issues/2352)) ([5bf46ee](https://github.com/googleapis/google-api-go-client/commit/5bf46ee341989dc8ceab2d08567cf5943aed5cdc))
* **all:** Auto-regenerate discovery clients ([#2353](https://github.com/googleapis/google-api-go-client/issues/2353)) ([da330c2](https://github.com/googleapis/google-api-go-client/commit/da330c2370a028b00e4056b87f816ad4295760ff))
* **all:** Auto-regenerate discovery clients ([#2354](https://github.com/googleapis/google-api-go-client/issues/2354)) ([0d002f9](https://github.com/googleapis/google-api-go-client/commit/0d002f9b0a70e0e144940c9812a6ebee6e4aa9b7))
* **all:** Auto-regenerate discovery clients ([#2358](https://github.com/googleapis/google-api-go-client/issues/2358)) ([72a8ffd](https://github.com/googleapis/google-api-go-client/commit/72a8ffde5c6840aac8519eca6ff0c6ee9ac0ad50))


### Documentation

* **option:** Update WithDefaultEndpointTemplate docs ([#2356](https://github.com/googleapis/google-api-go-client/issues/2356)) ([74a1558](https://github.com/googleapis/google-api-go-client/commit/74a1558e1a34d4a46ce5053c2de87ac1acf20108))

## [0.156.0](https://github.com/googleapis/google-api-go-client/compare/v0.155.0...v0.156.0) (2024-01-11)


### Features

* **all:** Auto-regenerate discovery clients ([#2332](https://github.com/googleapis/google-api-go-client/issues/2332)) ([014a8e0](https://github.com/googleapis/google-api-go-client/commit/014a8e01608c8d0239aa2bf9f037113e2cb00230))
* **all:** Auto-regenerate discovery clients ([#2336](https://github.com/googleapis/google-api-go-client/issues/2336)) ([bd4dad1](https://github.com/googleapis/google-api-go-client/commit/bd4dad1bbf15df181550bd430672638f6f2f6cb1))
* **all:** Auto-regenerate discovery clients ([#2337](https://github.com/googleapis/google-api-go-client/issues/2337)) ([ceefb9b](https://github.com/googleapis/google-api-go-client/commit/ceefb9b6def3cfa0b33dad38034d5348394e347d))
* **all:** Auto-regenerate discovery clients ([#2339](https://github.com/googleapis/google-api-go-client/issues/2339)) ([d008b6e](https://github.com/googleapis/google-api-go-client/commit/d008b6e30d7d278ca63facbc6734cfc2d281babe))
* **all:** Auto-regenerate discovery clients ([#2341](https://github.com/googleapis/google-api-go-client/issues/2341)) ([3f90b98](https://github.com/googleapis/google-api-go-client/commit/3f90b98750900ff1b5a5f4630ee8a651822b9697))
* **all:** Auto-regenerate discovery clients ([#2343](https://github.com/googleapis/google-api-go-client/issues/2343)) ([811e925](https://github.com/googleapis/google-api-go-client/commit/811e9257430d773224c4f59b16e8272eef9db952))
* **all:** Auto-regenerate discovery clients ([#2344](https://github.com/googleapis/google-api-go-client/issues/2344)) ([05de776](https://github.com/googleapis/google-api-go-client/commit/05de776445cab5f6a04a23f3d8b4afbd80b7910f))
* **google-api-go-generator:** Add universe domain support ([#2335](https://github.com/googleapis/google-api-go-client/issues/2335)) ([9e45101](https://github.com/googleapis/google-api-go-client/commit/9e4510161d1a3d52fbfce11ea2cd47435f17f3b1))

## [0.155.0](https://github.com/googleapis/google-api-go-client/compare/v0.154.0...v0.155.0) (2024-01-04)


### Features

* **all:** Auto-regenerate discovery clients ([#2302](https://github.com/googleapis/google-api-go-client/issues/2302)) ([e2d35d5](https://github.com/googleapis/google-api-go-client/commit/e2d35d5701b1b82c2ec34a7a5ba3eb65a477e702))
* **all:** Auto-regenerate discovery clients ([#2306](https://github.com/googleapis/google-api-go-client/issues/2306)) ([101074c](https://github.com/googleapis/google-api-go-client/commit/101074ca89de99afa5135f3cff6ba41b3a8bce05))
* **all:** Auto-regenerate discovery clients ([#2307](https://github.com/googleapis/google-api-go-client/issues/2307)) ([96c0dea](https://github.com/googleapis/google-api-go-client/commit/96c0dea3474d75a6768acb87169ef8cae5a6db22))
* **all:** Auto-regenerate discovery clients ([#2308](https://github.com/googleapis/google-api-go-client/issues/2308)) ([8c26aa7](https://github.com/googleapis/google-api-go-client/commit/8c26aa790106b1015999bcd62895449189d8bf3b))
* **all:** Auto-regenerate discovery clients ([#2309](https://github.com/googleapis/google-api-go-client/issues/2309)) ([a9a45c4](https://github.com/googleapis/google-api-go-client/commit/a9a45c4aab9082ac49164c3d548950f79a40092f))
* **all:** Auto-regenerate discovery clients ([#2312](https://github.com/googleapis/google-api-go-client/issues/2312)) ([bb522ac](https://github.com/googleapis/google-api-go-client/commit/bb522ac7eda7a91288d78459c99d1f6f8bd90c0c))
* **all:** Auto-regenerate discovery clients ([#2316](https://github.com/googleapis/google-api-go-client/issues/2316)) ([f01739e](https://github.com/googleapis/google-api-go-client/commit/f01739eb94574c1dd703e3c6782a538340bfb6a8))
* **all:** Auto-regenerate discovery clients ([#2317](https://github.com/googleapis/google-api-go-client/issues/2317)) ([16c2b92](https://github.com/googleapis/google-api-go-client/commit/16c2b92b24efd86e4da028dc6ca225c5e2cf9a89))
* **all:** Auto-regenerate discovery clients ([#2318](https://github.com/googleapis/google-api-go-client/issues/2318)) ([78596d4](https://github.com/googleapis/google-api-go-client/commit/78596d4ffbbf6091e6eac5a1a79ab37ad5faa24a))
* **all:** Auto-regenerate discovery clients ([#2319](https://github.com/googleapis/google-api-go-client/issues/2319)) ([6b9df05](https://github.com/googleapis/google-api-go-client/commit/6b9df050e65defb714daaf97202a38a58e88e6d1))
* **all:** Auto-regenerate discovery clients ([#2320](https://github.com/googleapis/google-api-go-client/issues/2320)) ([96bbfbe](https://github.com/googleapis/google-api-go-client/commit/96bbfbebadf650069719cba8359b80bac6107372))
* **all:** Auto-regenerate discovery clients ([#2322](https://github.com/googleapis/google-api-go-client/issues/2322)) ([1102aec](https://github.com/googleapis/google-api-go-client/commit/1102aec90dfac7a31b13ae1a545dbdb6d78a1410))
* **all:** Auto-regenerate discovery clients ([#2324](https://github.com/googleapis/google-api-go-client/issues/2324)) ([cc0275b](https://github.com/googleapis/google-api-go-client/commit/cc0275b84be03d3c3269c0de9dc2a19a70c26218))
* **all:** Auto-regenerate discovery clients ([#2327](https://github.com/googleapis/google-api-go-client/issues/2327)) ([aa81823](https://github.com/googleapis/google-api-go-client/commit/aa81823a238dafeeba5a6bca6989ba63d4bccba7))
* **all:** Auto-regenerate discovery clients ([#2328](https://github.com/googleapis/google-api-go-client/issues/2328)) ([9502f9c](https://github.com/googleapis/google-api-go-client/commit/9502f9cd6533c407ab46a32b044db0df2e5df6ca))
* **all:** Auto-regenerate discovery clients ([#2330](https://github.com/googleapis/google-api-go-client/issues/2330)) ([03de26a](https://github.com/googleapis/google-api-go-client/commit/03de26a7fd456962f4275a1adcf78de9665158bd))
* **all:** Auto-regenerate discovery clients ([#2331](https://github.com/googleapis/google-api-go-client/issues/2331)) ([858fb57](https://github.com/googleapis/google-api-go-client/commit/858fb5799f91dcb4b9d5b6949f3b22a1618c2071))
* **option/internaloption:** Add WithDefaultEndpointTemplate ([#2313](https://github.com/googleapis/google-api-go-client/issues/2313)) ([9e6e0c7](https://github.com/googleapis/google-api-go-client/commit/9e6e0c7c72dfa0a1505c14ff62119b7534f4d312)), refs [#2264](https://github.com/googleapis/google-api-go-client/issues/2264)
* **transport:** Add support for API keys for gprc ([#2326](https://github.com/googleapis/google-api-go-client/issues/2326)) ([9dbfb73](https://github.com/googleapis/google-api-go-client/commit/9dbfb73d31f050b998cf111b09a084c07583bcb3)), refs [#485](https://github.com/googleapis/google-api-go-client/issues/485)


### Bug Fixes

* **transport:** Fix memory leak in grpc.Dial ([#2329](https://github.com/googleapis/google-api-go-client/issues/2329)) ([240f763](https://github.com/googleapis/google-api-go-client/commit/240f7630086da518b03dcc792dbff13d571fbe94)), refs [#2321](https://github.com/googleapis/google-api-go-client/issues/2321)

## [0.154.0](https://github.com/googleapis/google-api-go-client/compare/v0.153.0...v0.154.0) (2023-12-12)


### Features

* **all:** Auto-regenerate discovery clients ([#2293](https://github.com/googleapis/google-api-go-client/issues/2293)) ([cefa0cd](https://github.com/googleapis/google-api-go-client/commit/cefa0cd8aa84b07e3882be261fb790f4b6770528))
* **all:** Auto-regenerate discovery clients ([#2294](https://github.com/googleapis/google-api-go-client/issues/2294)) ([c059038](https://github.com/googleapis/google-api-go-client/commit/c0590386a1c43d94137561502bf8dc42a6cd6833))
* **all:** Auto-regenerate discovery clients ([#2295](https://github.com/googleapis/google-api-go-client/issues/2295)) ([161a8e5](https://github.com/googleapis/google-api-go-client/commit/161a8e529d513b43304f876b12944e4d13d65ada))
* **all:** Auto-regenerate discovery clients ([#2297](https://github.com/googleapis/google-api-go-client/issues/2297)) ([e5e778a](https://github.com/googleapis/google-api-go-client/commit/e5e778aaffb6e54f263783b7a65525db0d067f9a))
* **all:** Auto-regenerate discovery clients ([#2298](https://github.com/googleapis/google-api-go-client/issues/2298)) ([d27a8e0](https://github.com/googleapis/google-api-go-client/commit/d27a8e0093c32c77fd94e077e78bd825dc191b80))
* **all:** Auto-regenerate discovery clients ([#2300](https://github.com/googleapis/google-api-go-client/issues/2300)) ([be0daf0](https://github.com/googleapis/google-api-go-client/commit/be0daf05c3f4597a99289d18ef54df112432cd13))
* **transport:** Add OpenTelemetry context propagation ([#2127](https://github.com/googleapis/google-api-go-client/issues/2127)) ([46421d4](https://github.com/googleapis/google-api-go-client/commit/46421d477a0b93e0bf5894fc9cc3599b06f9f85c))

## [0.153.0](https://github.com/googleapis/google-api-go-client/compare/v0.152.0...v0.153.0) (2023-12-05)


### Features

* **all:** Auto-regenerate discovery clients ([#2276](https://github.com/googleapis/google-api-go-client/issues/2276)) ([510f0f9](https://github.com/googleapis/google-api-go-client/commit/510f0f92034370f5164063af521c7a383b823b3e))
* **all:** Auto-regenerate discovery clients ([#2279](https://github.com/googleapis/google-api-go-client/issues/2279)) ([d07fe32](https://github.com/googleapis/google-api-go-client/commit/d07fe323e887d43e0b3a4bdd9c9c9f9c62ea34af))
* **all:** Auto-regenerate discovery clients ([#2280](https://github.com/googleapis/google-api-go-client/issues/2280)) ([e8e2895](https://github.com/googleapis/google-api-go-client/commit/e8e2895d6965b0304bfe7b9a964302275b41b09f))
* **all:** Auto-regenerate discovery clients ([#2283](https://github.com/googleapis/google-api-go-client/issues/2283)) ([bdc87de](https://github.com/googleapis/google-api-go-client/commit/bdc87de2cbcd83567983bc12cf0f8638ff104f35))
* **all:** Auto-regenerate discovery clients ([#2286](https://github.com/googleapis/google-api-go-client/issues/2286)) ([7897739](https://github.com/googleapis/google-api-go-client/commit/789773971f9eeacdeb0f6f0c13c9b04e3269f951))
* **all:** Auto-regenerate discovery clients ([#2287](https://github.com/googleapis/google-api-go-client/issues/2287)) ([4148872](https://github.com/googleapis/google-api-go-client/commit/414887212d8b6b2bca29e0d291fafaf84e142b07))
* **all:** Auto-regenerate discovery clients ([#2290](https://github.com/googleapis/google-api-go-client/issues/2290)) ([9f55397](https://github.com/googleapis/google-api-go-client/commit/9f55397fcea161b32ba14b5f6bb25f85abda0aa3))
* **all:** Auto-regenerate discovery clients ([#2291](https://github.com/googleapis/google-api-go-client/issues/2291)) ([0a6ebe4](https://github.com/googleapis/google-api-go-client/commit/0a6ebe42419ee01f95ff02cd51e041d4fe7a0678))
* Expose experimental universe-related options ([#2264](https://github.com/googleapis/google-api-go-client/issues/2264)) ([e648a9d](https://github.com/googleapis/google-api-go-client/commit/e648a9d2cc0ed492ea50a1d312ab17c812a2272c))
* Update workloadmanager api manually ([#2282](https://github.com/googleapis/google-api-go-client/issues/2282)) ([4aaad57](https://github.com/googleapis/google-api-go-client/commit/4aaad573b05144eac4fcf57753303b3b82393f02))

## [0.152.0](https://github.com/googleapis/google-api-go-client/compare/v0.151.0...v0.152.0) (2023-11-27)


### Features

* **all:** Auto-regenerate discovery clients ([#2266](https://github.com/googleapis/google-api-go-client/issues/2266)) ([22872aa](https://github.com/googleapis/google-api-go-client/commit/22872aac175d8591bd71c556426d8f6c34e12058))
* **all:** Auto-regenerate discovery clients ([#2268](https://github.com/googleapis/google-api-go-client/issues/2268)) ([980c045](https://github.com/googleapis/google-api-go-client/commit/980c045566d471ab3c5a505a652fbab089dd82cc))
* **all:** Auto-regenerate discovery clients ([#2269](https://github.com/googleapis/google-api-go-client/issues/2269)) ([3138958](https://github.com/googleapis/google-api-go-client/commit/31389583c26dc033b75a332675ce90a21b348380))
* **all:** Auto-regenerate discovery clients ([#2270](https://github.com/googleapis/google-api-go-client/issues/2270)) ([4ffc629](https://github.com/googleapis/google-api-go-client/commit/4ffc629f3bd1712513acec389a069745851b1e3b))
* **all:** Auto-regenerate discovery clients ([#2271](https://github.com/googleapis/google-api-go-client/issues/2271)) ([82f1381](https://github.com/googleapis/google-api-go-client/commit/82f1381862746297aa366744f06518a423f9a4f1))

## [0.151.0](https://github.com/googleapis/google-api-go-client/compare/v0.150.0...v0.151.0) (2023-11-16)


### Features

* **all:** Auto-regenerate discovery clients ([#2253](https://github.com/googleapis/google-api-go-client/issues/2253)) ([58f1c94](https://github.com/googleapis/google-api-go-client/commit/58f1c94d0de3b0e7715428ccc5ca17f1dfbab076))
* **all:** Auto-regenerate discovery clients ([#2255](https://github.com/googleapis/google-api-go-client/issues/2255)) ([10dbf2b](https://github.com/googleapis/google-api-go-client/commit/10dbf2b5d87783d3dc3de50ea627e740c784137a))
* **all:** Auto-regenerate discovery clients ([#2256](https://github.com/googleapis/google-api-go-client/issues/2256)) ([4024760](https://github.com/googleapis/google-api-go-client/commit/4024760da1cdf46e2e79495e65c5ddd1c2251d07))
* **all:** Auto-regenerate discovery clients ([#2257](https://github.com/googleapis/google-api-go-client/issues/2257)) ([b3fe441](https://github.com/googleapis/google-api-go-client/commit/b3fe441cccb3832da66b96ee3cb7a11db96bde53))
* **all:** Auto-regenerate discovery clients ([#2258](https://github.com/googleapis/google-api-go-client/issues/2258)) ([efe3d6f](https://github.com/googleapis/google-api-go-client/commit/efe3d6fd433ece9d59ce8b747774881f0fcf410c))
* **all:** Auto-regenerate discovery clients ([#2259](https://github.com/googleapis/google-api-go-client/issues/2259)) ([33863bf](https://github.com/googleapis/google-api-go-client/commit/33863bf9a68ec56ad0ebac93e614d3628b81416c))
* **all:** Auto-regenerate discovery clients ([#2261](https://github.com/googleapis/google-api-go-client/issues/2261)) ([edb9d86](https://github.com/googleapis/google-api-go-client/commit/edb9d869deb8bb98b9721cbaaa9703bc04a609fa))
* **all:** Auto-regenerate discovery clients ([#2262](https://github.com/googleapis/google-api-go-client/issues/2262)) ([93f5a5b](https://github.com/googleapis/google-api-go-client/commit/93f5a5bf913a771c774143e3bf9bd634d80bc7d8))
* **all:** Auto-regenerate discovery clients ([#2263](https://github.com/googleapis/google-api-go-client/issues/2263)) ([3e83ea6](https://github.com/googleapis/google-api-go-client/commit/3e83ea6f3926a6fbdd92e05db7f4e4705e7789ba))
* **all:** Auto-regenerate discovery clients ([#2265](https://github.com/googleapis/google-api-go-client/issues/2265)) ([786dca6](https://github.com/googleapis/google-api-go-client/commit/786dca6dfcb777d7dd6724fe08ccc424ad8e992e))

## [0.150.0](https://github.com/googleapis/google-api-go-client/compare/v0.149.0...v0.150.0) (2023-11-06)


### Features

* **all:** Auto-regenerate discovery clients ([#2243](https://github.com/googleapis/google-api-go-client/issues/2243)) ([2ce2d2d](https://github.com/googleapis/google-api-go-client/commit/2ce2d2d63343cae224e0f44f37d0426e9c7acbaa))
* **all:** Auto-regenerate discovery clients ([#2245](https://github.com/googleapis/google-api-go-client/issues/2245)) ([5693997](https://github.com/googleapis/google-api-go-client/commit/56939974844fd102839077f56ca84454458749f2))
* **all:** Auto-regenerate discovery clients ([#2246](https://github.com/googleapis/google-api-go-client/issues/2246)) ([8bfbeac](https://github.com/googleapis/google-api-go-client/commit/8bfbeaca4cb80ffe972d56762c832ed31785e8ca))
* **all:** Auto-regenerate discovery clients ([#2249](https://github.com/googleapis/google-api-go-client/issues/2249)) ([b56da3d](https://github.com/googleapis/google-api-go-client/commit/b56da3d6d7c0ad083d8835dead8f681de263fa39))
* **all:** Auto-regenerate discovery clients ([#2250](https://github.com/googleapis/google-api-go-client/issues/2250)) ([c08d405](https://github.com/googleapis/google-api-go-client/commit/c08d405c38ecd133175b932232211e046c4aa07c))
* **all:** Auto-regenerate discovery clients ([#2252](https://github.com/googleapis/google-api-go-client/issues/2252)) ([7529003](https://github.com/googleapis/google-api-go-client/commit/752900316914347301220b5f5dc2eb5eea2a8325))
* **transport:** Log DirectPath misconfiguration ([#2225](https://github.com/googleapis/google-api-go-client/issues/2225)) ([85e85ad](https://github.com/googleapis/google-api-go-client/commit/85e85ad04e28b434dd731c3b537d0fc35ff3639a))

## [0.149.0](https://github.com/googleapis/google-api-go-client/compare/v0.148.0...v0.149.0) (2023-10-31)


### Features

* **all:** Auto-regenerate discovery clients ([#2229](https://github.com/googleapis/google-api-go-client/issues/2229)) ([199783c](https://github.com/googleapis/google-api-go-client/commit/199783cee2a58c41a8a38184a01bfe159363d3f9))
* **all:** Auto-regenerate discovery clients ([#2231](https://github.com/googleapis/google-api-go-client/issues/2231)) ([9835f38](https://github.com/googleapis/google-api-go-client/commit/9835f38d845e090044304dd6420acf942b1b54f8))
* **all:** Auto-regenerate discovery clients ([#2232](https://github.com/googleapis/google-api-go-client/issues/2232)) ([a1fb230](https://github.com/googleapis/google-api-go-client/commit/a1fb23059083c36f6ae1a631fc325d945eedc99e))
* **all:** Auto-regenerate discovery clients ([#2234](https://github.com/googleapis/google-api-go-client/issues/2234)) ([8bb5867](https://github.com/googleapis/google-api-go-client/commit/8bb586701787597c9fc9f9baad980fff48e9a329))
* **all:** Auto-regenerate discovery clients ([#2235](https://github.com/googleapis/google-api-go-client/issues/2235)) ([cc28ceb](https://github.com/googleapis/google-api-go-client/commit/cc28ceb36a083703dd7bb46fa3b7baadad381b25))
* **all:** Auto-regenerate discovery clients ([#2236](https://github.com/googleapis/google-api-go-client/issues/2236)) ([da38ebd](https://github.com/googleapis/google-api-go-client/commit/da38ebdd07b760f8bd9958287c61895b73413d18))
* **all:** Auto-regenerate discovery clients ([#2237](https://github.com/googleapis/google-api-go-client/issues/2237)) ([3cc10bf](https://github.com/googleapis/google-api-go-client/commit/3cc10bf39b90baa82dae5c60c060153659952005))
* **all:** Auto-regenerate discovery clients ([#2238](https://github.com/googleapis/google-api-go-client/issues/2238)) ([8d66391](https://github.com/googleapis/google-api-go-client/commit/8d66391179d88a910a5637129c0f520fbcabe93e))
* **all:** Auto-regenerate discovery clients ([#2239](https://github.com/googleapis/google-api-go-client/issues/2239)) ([cf09469](https://github.com/googleapis/google-api-go-client/commit/cf0946900398f3eccf2fea8ffefdd1bd55be8d5e))
* **all:** Auto-regenerate discovery clients ([#2240](https://github.com/googleapis/google-api-go-client/issues/2240)) ([3151bd7](https://github.com/googleapis/google-api-go-client/commit/3151bd7998eca6d2f2ca22017803480057efabe6))
* **all:** Auto-regenerate discovery clients ([#2241](https://github.com/googleapis/google-api-go-client/issues/2241)) ([576f5e1](https://github.com/googleapis/google-api-go-client/commit/576f5e1fc45885023aa53f0588e2b9dc6e917414))
* **all:** Auto-regenerate discovery clients ([#2242](https://github.com/googleapis/google-api-go-client/issues/2242)) ([c84e6ff](https://github.com/googleapis/google-api-go-client/commit/c84e6ffaf80d3139a0c434864613c96762e6eaf9))

## [0.148.0](https://github.com/googleapis/google-api-go-client/compare/v0.147.0...v0.148.0) (2023-10-19)


### Features

* **all:** Auto-regenerate discovery clients ([#2216](https://github.com/googleapis/google-api-go-client/issues/2216)) ([ffeb508](https://github.com/googleapis/google-api-go-client/commit/ffeb5088b7f259a9db9979844af269d4ea792b76))
* **all:** Auto-regenerate discovery clients ([#2218](https://github.com/googleapis/google-api-go-client/issues/2218)) ([1ef9dd2](https://github.com/googleapis/google-api-go-client/commit/1ef9dd2a968eec0ad0e5ace4f19d07009d014ce3))
* **all:** Auto-regenerate discovery clients ([#2219](https://github.com/googleapis/google-api-go-client/issues/2219)) ([6f71a69](https://github.com/googleapis/google-api-go-client/commit/6f71a6920bd9185b3c0f50772d23eb96090328c2))
* **all:** Auto-regenerate discovery clients ([#2222](https://github.com/googleapis/google-api-go-client/issues/2222)) ([a6ee0f9](https://github.com/googleapis/google-api-go-client/commit/a6ee0f9a287449f95f10cb53b2fd492bb8fe1fd3))
* **all:** Auto-regenerate discovery clients ([#2224](https://github.com/googleapis/google-api-go-client/issues/2224)) ([25093c2](https://github.com/googleapis/google-api-go-client/commit/25093c222db5ff0fec8d97782bd65d2661f39f9c))
* **all:** Auto-regenerate discovery clients ([#2226](https://github.com/googleapis/google-api-go-client/issues/2226)) ([33383c7](https://github.com/googleapis/google-api-go-client/commit/33383c78b4883bbd6e441e990d7002124e35cc39))
* **all:** Auto-regenerate discovery clients ([#2227](https://github.com/googleapis/google-api-go-client/issues/2227)) ([29c72b5](https://github.com/googleapis/google-api-go-client/commit/29c72b5318389498bd7d21636ef36a676a0592e2))

## [0.147.0](https://github.com/googleapis/google-api-go-client/compare/v0.146.0...v0.147.0) (2023-10-12)


### Features

* **all:** Auto-regenerate discovery clients ([#2209](https://github.com/googleapis/google-api-go-client/issues/2209)) ([f2c2d1b](https://github.com/googleapis/google-api-go-client/commit/f2c2d1b88bd5fc89159e70085ed2ac4859f19d94))
* **all:** Auto-regenerate discovery clients ([#2211](https://github.com/googleapis/google-api-go-client/issues/2211)) ([df0b730](https://github.com/googleapis/google-api-go-client/commit/df0b7304e8e684ce8d908c6e4c4119f2833fcbd8))
* **all:** Auto-regenerate discovery clients ([#2215](https://github.com/googleapis/google-api-go-client/issues/2215)) ([e2368f8](https://github.com/googleapis/google-api-go-client/commit/e2368f8f4b0edd4fa913473f2a8dde542e8b2dbb))

## [0.146.0](https://github.com/googleapis/google-api-go-client/compare/v0.145.0...v0.146.0) (2023-10-08)


### Features

* **all:** Auto-regenerate discovery clients ([#2203](https://github.com/googleapis/google-api-go-client/issues/2203)) ([1e9a43c](https://github.com/googleapis/google-api-go-client/commit/1e9a43c445b3d9a88d3515042d5ff68ef7792fb9))
* **all:** Auto-regenerate discovery clients ([#2205](https://github.com/googleapis/google-api-go-client/issues/2205)) ([4aa710d](https://github.com/googleapis/google-api-go-client/commit/4aa710dc2764f4b58da997a460f860aeded99c02))
* **all:** Auto-regenerate discovery clients ([#2206](https://github.com/googleapis/google-api-go-client/issues/2206)) ([9a034cd](https://github.com/googleapis/google-api-go-client/commit/9a034cd03b091602a154a046eec8a3a0019bed39))

## [0.145.0](https://github.com/googleapis/google-api-go-client/compare/v0.144.0...v0.145.0) (2023-10-05)


### Features

* **all:** Auto-regenerate discovery clients ([#2201](https://github.com/googleapis/google-api-go-client/issues/2201)) ([c26a28c](https://github.com/googleapis/google-api-go-client/commit/c26a28c0d27c2cb937c794a487f31b61e21994c6))

## [0.144.0](https://github.com/googleapis/google-api-go-client/compare/v0.143.0...v0.144.0) (2023-10-04)


### Features

* **all:** Auto-regenerate discovery clients ([#2187](https://github.com/googleapis/google-api-go-client/issues/2187)) ([65ec288](https://github.com/googleapis/google-api-go-client/commit/65ec288cfc33018f944b9e139ca3d3afaf5caee1))
* **all:** Auto-regenerate discovery clients ([#2189](https://github.com/googleapis/google-api-go-client/issues/2189)) ([ec24c23](https://github.com/googleapis/google-api-go-client/commit/ec24c233d0b917fba3d2a51edea9b8bee940f919))
* **all:** Auto-regenerate discovery clients ([#2190](https://github.com/googleapis/google-api-go-client/issues/2190)) ([f930302](https://github.com/googleapis/google-api-go-client/commit/f9303021c3e888ec75ccaf5aaebc0c646655c669))
* **all:** Auto-regenerate discovery clients ([#2191](https://github.com/googleapis/google-api-go-client/issues/2191)) ([0132460](https://github.com/googleapis/google-api-go-client/commit/013246038d46546a6e3f3bf3d7d492c24489029a))
* **all:** Auto-regenerate discovery clients ([#2192](https://github.com/googleapis/google-api-go-client/issues/2192)) ([8a3eb9b](https://github.com/googleapis/google-api-go-client/commit/8a3eb9bca62a75671e97a7b57dd786a5c520515a))
* **all:** Auto-regenerate discovery clients ([#2193](https://github.com/googleapis/google-api-go-client/issues/2193)) ([55f1113](https://github.com/googleapis/google-api-go-client/commit/55f1113904bd3c786d5f956f71899f7bf86fc1e8))
* **all:** Auto-regenerate discovery clients ([#2195](https://github.com/googleapis/google-api-go-client/issues/2195)) ([0c82427](https://github.com/googleapis/google-api-go-client/commit/0c82427738cda79e331d5cf418bb24dc9235a32f))
* **all:** Auto-regenerate discovery clients ([#2196](https://github.com/googleapis/google-api-go-client/issues/2196)) ([34e0216](https://github.com/googleapis/google-api-go-client/commit/34e02167d9a3f2d6a72be25a0865a5b86825d80e))
* **all:** Auto-regenerate discovery clients ([#2197](https://github.com/googleapis/google-api-go-client/issues/2197)) ([5779cfc](https://github.com/googleapis/google-api-go-client/commit/5779cfc67b64c813eb013fc093aaf6accff096dd))

## [0.143.0](https://github.com/googleapis/google-api-go-client/compare/v0.142.0...v0.143.0) (2023-09-25)


### Features

* **all:** Auto-regenerate discovery clients ([#2173](https://github.com/googleapis/google-api-go-client/issues/2173)) ([68d92d4](https://github.com/googleapis/google-api-go-client/commit/68d92d4c330a779c86eb07966b9da4161862e2a9))
* **all:** Auto-regenerate discovery clients ([#2176](https://github.com/googleapis/google-api-go-client/issues/2176)) ([c6a8850](https://github.com/googleapis/google-api-go-client/commit/c6a8850e2e0d66f9b4c22a87e02a6cdad880898e))
* **all:** Auto-regenerate discovery clients ([#2177](https://github.com/googleapis/google-api-go-client/issues/2177)) ([00aa328](https://github.com/googleapis/google-api-go-client/commit/00aa32815374abed5ce287963ee647360ab69707))
* **all:** Auto-regenerate discovery clients ([#2179](https://github.com/googleapis/google-api-go-client/issues/2179)) ([1bca7ee](https://github.com/googleapis/google-api-go-client/commit/1bca7ee850540c93f70c43ceee7d99bdc94c9620))
* **all:** Auto-regenerate discovery clients ([#2180](https://github.com/googleapis/google-api-go-client/issues/2180)) ([e61e11b](https://github.com/googleapis/google-api-go-client/commit/e61e11bf1e4d201e87b95758dee087fbfe089a93))
* **all:** Auto-regenerate discovery clients ([#2182](https://github.com/googleapis/google-api-go-client/issues/2182)) ([4c049c5](https://github.com/googleapis/google-api-go-client/commit/4c049c51e27a06d2a24f5124f786ec524c0f619a))


### Bug Fixes

* **docs:** Add an operation polling example ([#2186](https://github.com/googleapis/google-api-go-client/issues/2186)) ([bd12eba](https://github.com/googleapis/google-api-go-client/commit/bd12ebaeb0a55d37c24881968981058f5a80f15a))

## [0.142.0](https://github.com/googleapis/google-api-go-client/compare/v0.141.0...v0.142.0) (2023-09-19)


### Features

* **all:** Auto-regenerate discovery clients ([#2161](https://github.com/googleapis/google-api-go-client/issues/2161)) ([d6822ad](https://github.com/googleapis/google-api-go-client/commit/d6822ad7882205ad60c6cd35997273b6c0d18d16))
* **all:** Auto-regenerate discovery clients ([#2165](https://github.com/googleapis/google-api-go-client/issues/2165)) ([304fb51](https://github.com/googleapis/google-api-go-client/commit/304fb51a451f64eb6e91ed66e05a2bec7fe7288e))
* **all:** Auto-regenerate discovery clients ([#2166](https://github.com/googleapis/google-api-go-client/issues/2166)) ([c4024ed](https://github.com/googleapis/google-api-go-client/commit/c4024ed757507b9e711a1c57b9efcd265a36be5f))
* **all:** Auto-regenerate discovery clients ([#2168](https://github.com/googleapis/google-api-go-client/issues/2168)) ([0c5c2d2](https://github.com/googleapis/google-api-go-client/commit/0c5c2d24d5566d9bca6c1ad5922f821bb39966a0))
* **all:** Auto-regenerate discovery clients ([#2171](https://github.com/googleapis/google-api-go-client/issues/2171)) ([da71d0a](https://github.com/googleapis/google-api-go-client/commit/da71d0a5b1d79d38dad62a4d83a612e7c705f0f1))
* **all:** Use updated mtls config endpoint ([#2164](https://github.com/googleapis/google-api-go-client/issues/2164)) ([a8cadbf](https://github.com/googleapis/google-api-go-client/commit/a8cadbf156fa75f0fd7a46d80de485c15647c58a))
* **internal:** Add some feature flags for new auth libs ([#2163](https://github.com/googleapis/google-api-go-client/issues/2163)) ([a34ad77](https://github.com/googleapis/google-api-go-client/commit/a34ad7790416dac4680e201d00f95be37b5de93c))

## [0.141.0](https://github.com/googleapis/google-api-go-client/compare/v0.140.0...v0.141.0) (2023-09-14)


### Features

* **all:** Auto-regenerate discovery clients ([#2155](https://github.com/googleapis/google-api-go-client/issues/2155)) ([9a84e80](https://github.com/googleapis/google-api-go-client/commit/9a84e802e0a0bb8424950cdf2bcad83a90999496))
* **all:** Auto-regenerate discovery clients ([#2159](https://github.com/googleapis/google-api-go-client/issues/2159)) ([2b846e5](https://github.com/googleapis/google-api-go-client/commit/2b846e55cfdffb0e5e100f5d75f06691fdb7d845))
* **all:** Auto-regenerate discovery clients ([#2160](https://github.com/googleapis/google-api-go-client/issues/2160)) ([124e36e](https://github.com/googleapis/google-api-go-client/commit/124e36ed4056ec913dc30ace452277d20a0e059c))
* **idtoken:** Add ParsePayload returning unvalidated token payload ([#2136](https://github.com/googleapis/google-api-go-client/issues/2136)) ([d541d8e](https://github.com/googleapis/google-api-go-client/commit/d541d8e4f6699db6216a0aeee5a7a5c23ed8a3b7))


### Bug Fixes

* **transport:** Remove conditional App Engine gen 1 Go hooks ([#2158](https://github.com/googleapis/google-api-go-client/issues/2158)) ([c2fa93e](https://github.com/googleapis/google-api-go-client/commit/c2fa93e001e9c6b60c17ac35161e6bdff0b2873e)), refs [#2128](https://github.com/googleapis/google-api-go-client/issues/2128)

## [0.140.0](https://github.com/googleapis/google-api-go-client/compare/v0.139.0...v0.140.0) (2023-09-11)


### Features

* **all:** Auto-regenerate discovery clients ([#2144](https://github.com/googleapis/google-api-go-client/issues/2144)) ([aded622](https://github.com/googleapis/google-api-go-client/commit/aded622e1588af20443988563f91a493322e3b02))
* **all:** Auto-regenerate discovery clients ([#2148](https://github.com/googleapis/google-api-go-client/issues/2148)) ([b6072d6](https://github.com/googleapis/google-api-go-client/commit/b6072d62905abf4b0f2386ce81ea85db4a51f7a2))
* **all:** Auto-regenerate discovery clients ([#2149](https://github.com/googleapis/google-api-go-client/issues/2149)) ([161e093](https://github.com/googleapis/google-api-go-client/commit/161e093a56763c64c9e0b16ee1940dc6969d1ead))
* **all:** Auto-regenerate discovery clients ([#2150](https://github.com/googleapis/google-api-go-client/issues/2150)) ([1038447](https://github.com/googleapis/google-api-go-client/commit/1038447595fb8c1e1db8cb526084163a8dd786db))
* **all:** Auto-regenerate discovery clients ([#2152](https://github.com/googleapis/google-api-go-client/issues/2152)) ([1183ccf](https://github.com/googleapis/google-api-go-client/commit/1183ccf873b0f4e09e896d31a4d8ec7ad6f2ef1b))

## [0.139.0](https://github.com/googleapis/google-api-go-client/compare/v0.138.0...v0.139.0) (2023-09-08)


### Features

* **all:** Auto-regenerate discovery clients ([#2120](https://github.com/googleapis/google-api-go-client/issues/2120)) ([fd53dce](https://github.com/googleapis/google-api-go-client/commit/fd53dcead5d0eda81cfcd480ed1263c668e30510))
* **all:** Auto-regenerate discovery clients ([#2142](https://github.com/googleapis/google-api-go-client/issues/2142)) ([8e1c21a](https://github.com/googleapis/google-api-go-client/commit/8e1c21a164e10b3fe3c94d47c637e9a236c5aa09))


### Documentation

* Point more users forward ([#2126](https://github.com/googleapis/google-api-go-client/issues/2126)) ([62d88ff](https://github.com/googleapis/google-api-go-client/commit/62d88ff7c06b828324b3cf5fd004cdf75838f496))

## [0.138.0](https://github.com/googleapis/google-api-go-client/compare/v0.137.0...v0.138.0) (2023-08-17)


### Features

* **all:** Auto-regenerate discovery clients ([#2115](https://github.com/googleapis/google-api-go-client/issues/2115)) ([1770219](https://github.com/googleapis/google-api-go-client/commit/17702192ed1c3520841bf005504d62a675f9a2b0))
* **all:** Auto-regenerate discovery clients ([#2118](https://github.com/googleapis/google-api-go-client/issues/2118)) ([40ea606](https://github.com/googleapis/google-api-go-client/commit/40ea606a2218396bcd4235737829f98057153852))
* **all:** Auto-regenerate discovery clients ([#2119](https://github.com/googleapis/google-api-go-client/issues/2119)) ([9b75278](https://github.com/googleapis/google-api-go-client/commit/9b7527848a21a7baffbac4778841d89eff45a515))

## [0.137.0](https://github.com/googleapis/google-api-go-client/compare/v0.136.0...v0.137.0) (2023-08-14)


### Features

* **all:** Auto-regenerate discovery clients ([#2106](https://github.com/googleapis/google-api-go-client/issues/2106)) ([3f3ed3d](https://github.com/googleapis/google-api-go-client/commit/3f3ed3da191394d25fd28f60ec1a51fddaf43a4a))
* **all:** Auto-regenerate discovery clients ([#2108](https://github.com/googleapis/google-api-go-client/issues/2108)) ([80485e0](https://github.com/googleapis/google-api-go-client/commit/80485e0e9a1bae98714d695ed2efff6187618d57))
* **all:** Auto-regenerate discovery clients ([#2110](https://github.com/googleapis/google-api-go-client/issues/2110)) ([4d775db](https://github.com/googleapis/google-api-go-client/commit/4d775db7cf6eb71fad1f67b022736f3b2de09a0b))
* **all:** Auto-regenerate discovery clients ([#2111](https://github.com/googleapis/google-api-go-client/issues/2111)) ([0cc62ab](https://github.com/googleapis/google-api-go-client/commit/0cc62aba44965ffc10e33c2e43cc7260e836e504))
* **all:** Auto-regenerate discovery clients ([#2112](https://github.com/googleapis/google-api-go-client/issues/2112)) ([f7f1c7b](https://github.com/googleapis/google-api-go-client/commit/f7f1c7b4c610f6a41c130c3bb85d6a609e99fb37))
* **all:** Auto-regenerate discovery clients ([#2113](https://github.com/googleapis/google-api-go-client/issues/2113)) ([142ffeb](https://github.com/googleapis/google-api-go-client/commit/142ffebac56456c904234248a004175aa41e035c))
* Ok to use S2A with override endpoint ([#2114](https://github.com/googleapis/google-api-go-client/issues/2114)) ([caea956](https://github.com/googleapis/google-api-go-client/commit/caea95689f82049822552cd649765335123831e0))

## [0.136.0](https://github.com/googleapis/google-api-go-client/compare/v0.135.0...v0.136.0) (2023-08-08)


### Features

* Add additional checks before using S2A ([#2103](https://github.com/googleapis/google-api-go-client/issues/2103)) ([c62e5c6](https://github.com/googleapis/google-api-go-client/commit/c62e5c6665e06611d792c892028c8e5e840f8447))
* **all:** Auto-regenerate discovery clients ([#2104](https://github.com/googleapis/google-api-go-client/issues/2104)) ([8029f73](https://github.com/googleapis/google-api-go-client/commit/8029f731063d2c0e6cd22e9a1e92b511e7105740))

## [0.135.0](https://github.com/googleapis/google-api-go-client/compare/v0.134.0...v0.135.0) (2023-08-07)


### Features

* **all:** Auto-regenerate discovery clients ([#2087](https://github.com/googleapis/google-api-go-client/issues/2087)) ([8875932](https://github.com/googleapis/google-api-go-client/commit/887593261797511aab9c7248c16dcf9340f87e0c))
* **all:** Auto-regenerate discovery clients ([#2089](https://github.com/googleapis/google-api-go-client/issues/2089)) ([c4d9f14](https://github.com/googleapis/google-api-go-client/commit/c4d9f1454037dbe8603cef2552cf9ce6992a8781))
* **all:** Auto-regenerate discovery clients ([#2090](https://github.com/googleapis/google-api-go-client/issues/2090)) ([8ba6963](https://github.com/googleapis/google-api-go-client/commit/8ba6963062f42f9745db3086e510427690e40964))
* **all:** Auto-regenerate discovery clients ([#2091](https://github.com/googleapis/google-api-go-client/issues/2091)) ([597995c](https://github.com/googleapis/google-api-go-client/commit/597995c005371797cba1357406a8b83cf447e345))
* **all:** Auto-regenerate discovery clients ([#2093](https://github.com/googleapis/google-api-go-client/issues/2093)) ([2b1c61f](https://github.com/googleapis/google-api-go-client/commit/2b1c61f398cb7e2d5608107e9dfa15e5d071161b))
* **all:** Auto-regenerate discovery clients ([#2094](https://github.com/googleapis/google-api-go-client/issues/2094)) ([979195d](https://github.com/googleapis/google-api-go-client/commit/979195dc3f80682f1e4800316898974f74d38b77))
* **all:** Auto-regenerate discovery clients ([#2095](https://github.com/googleapis/google-api-go-client/issues/2095)) ([1e19c22](https://github.com/googleapis/google-api-go-client/commit/1e19c228cf37b343283c5af2665517cd1596b2e1))
* **all:** Auto-regenerate discovery clients ([#2096](https://github.com/googleapis/google-api-go-client/issues/2096)) ([e59738c](https://github.com/googleapis/google-api-go-client/commit/e59738ce2254a7da00e49ae52e46f4bc9a9b7ee3))
* **all:** Auto-regenerate discovery clients ([#2098](https://github.com/googleapis/google-api-go-client/issues/2098)) ([ff054ff](https://github.com/googleapis/google-api-go-client/commit/ff054ffae64330a75d1e38448646b540eee3afbb))
* **all:** Auto-regenerate discovery clients ([#2099](https://github.com/googleapis/google-api-go-client/issues/2099)) ([b16a2d3](https://github.com/googleapis/google-api-go-client/commit/b16a2d31763144ab92c4eba73aa5fcc5b418789d))
* **all:** Auto-regenerate discovery clients ([#2100](https://github.com/googleapis/google-api-go-client/issues/2100)) ([262aa70](https://github.com/googleapis/google-api-go-client/commit/262aa706a39b99020c542fae1d5f8a73eb139e33))
* **all:** Auto-regenerate discovery clients ([#2102](https://github.com/googleapis/google-api-go-client/issues/2102)) ([8fbf572](https://github.com/googleapis/google-api-go-client/commit/8fbf5724ef77000d747c0457fbc0dbe6ee7da980))

## [0.134.0](https://github.com/googleapis/google-api-go-client/compare/v0.133.0...v0.134.0) (2023-07-26)


### Features

* **all:** Auto-regenerate discovery clients ([#2084](https://github.com/googleapis/google-api-go-client/issues/2084)) ([66d077d](https://github.com/googleapis/google-api-go-client/commit/66d077dbdef9a9c5cf83d88aaff80460b0207a9e))
* **all:** Auto-regenerate discovery clients ([#2086](https://github.com/googleapis/google-api-go-client/issues/2086)) ([aec89b7](https://github.com/googleapis/google-api-go-client/commit/aec89b79d52c03c5574ccadd83185b112b5b34fb))

## [0.133.0](https://github.com/googleapis/google-api-go-client/compare/v0.132.0...v0.133.0) (2023-07-24)


### Features

* **all:** Auto-regenerate discovery clients ([#2077](https://github.com/googleapis/google-api-go-client/issues/2077)) ([d9bd05b](https://github.com/googleapis/google-api-go-client/commit/d9bd05beb8861c3c1b2ac8e7dd57afcfcf871644))
* **all:** Auto-regenerate discovery clients ([#2079](https://github.com/googleapis/google-api-go-client/issues/2079)) ([b88678a](https://github.com/googleapis/google-api-go-client/commit/b88678afb55f875ad7673d049c8c0bb75affe116))
* **all:** Auto-regenerate discovery clients ([#2080](https://github.com/googleapis/google-api-go-client/issues/2080)) ([3a5236c](https://github.com/googleapis/google-api-go-client/commit/3a5236c9a884daf059ba58f90e7a842b18eefc4e))
* **all:** Auto-regenerate discovery clients ([#2081](https://github.com/googleapis/google-api-go-client/issues/2081)) ([94f3caf](https://github.com/googleapis/google-api-go-client/commit/94f3caf04025b4a169e6a307c54c20b8e388b956))
* **all:** Auto-regenerate discovery clients ([#2082](https://github.com/googleapis/google-api-go-client/issues/2082)) ([0846d92](https://github.com/googleapis/google-api-go-client/commit/0846d9297408b2a37932a3b907bd57df5e7da79a))

## [0.132.0](https://github.com/googleapis/google-api-go-client/compare/v0.131.0...v0.132.0) (2023-07-18)


### Features

* **all:** Auto-regenerate discovery clients ([#2065](https://github.com/googleapis/google-api-go-client/issues/2065)) ([25a3230](https://github.com/googleapis/google-api-go-client/commit/25a3230956a5524a55314a0959d2f251293128b4))
* **all:** Auto-regenerate discovery clients ([#2069](https://github.com/googleapis/google-api-go-client/issues/2069)) ([16cf0c3](https://github.com/googleapis/google-api-go-client/commit/16cf0c3c1f8d16ede4df09c6cbbbcd87cc38ad89))
* **all:** Auto-regenerate discovery clients ([#2072](https://github.com/googleapis/google-api-go-client/issues/2072)) ([52ac522](https://github.com/googleapis/google-api-go-client/commit/52ac52201c6d4bdbb5a5a7b841da53d053a3a00b))
* **all:** Auto-regenerate discovery clients ([#2073](https://github.com/googleapis/google-api-go-client/issues/2073)) ([0011a92](https://github.com/googleapis/google-api-go-client/commit/0011a92bffa275ec61ae37399c43c85fb0d1fecc))
* **all:** Auto-regenerate discovery clients ([#2075](https://github.com/googleapis/google-api-go-client/issues/2075)) ([25d96d9](https://github.com/googleapis/google-api-go-client/commit/25d96d9a958d3152c1ff50b19d2277211da862f3))
* **all:** Auto-regenerate discovery clients ([#2076](https://github.com/googleapis/google-api-go-client/issues/2076)) ([334c07e](https://github.com/googleapis/google-api-go-client/commit/334c07ed354828145ee6e61c3722471ee8260eb4))

## [0.131.0](https://github.com/googleapis/google-api-go-client/compare/v0.130.0...v0.131.0) (2023-07-12)


### Features

* **all:** Auto-regenerate discovery clients ([#2054](https://github.com/googleapis/google-api-go-client/issues/2054)) ([1b0f818](https://github.com/googleapis/google-api-go-client/commit/1b0f818bc9e7049967d49cafd6fe419c1c786c86))
* **all:** Auto-regenerate discovery clients ([#2058](https://github.com/googleapis/google-api-go-client/issues/2058)) ([e871335](https://github.com/googleapis/google-api-go-client/commit/e871335ad6700d89d2b9629db99d1e674d5b9cad))
* **all:** Auto-regenerate discovery clients ([#2059](https://github.com/googleapis/google-api-go-client/issues/2059)) ([24b4d0b](https://github.com/googleapis/google-api-go-client/commit/24b4d0b3c502e1f3cd7d73fdfcf039fe8b6fa08c))
* **all:** Auto-regenerate discovery clients ([#2060](https://github.com/googleapis/google-api-go-client/issues/2060)) ([16ad84c](https://github.com/googleapis/google-api-go-client/commit/16ad84c503bdf262a9b4868bcb87f790c4ac478e))
* **all:** Auto-regenerate discovery clients ([#2062](https://github.com/googleapis/google-api-go-client/issues/2062)) ([90038ee](https://github.com/googleapis/google-api-go-client/commit/90038ee5c30ccbb808ee5f645df900b08c99b162))
* **all:** Auto-regenerate discovery clients ([#2063](https://github.com/googleapis/google-api-go-client/issues/2063)) ([524f72b](https://github.com/googleapis/google-api-go-client/commit/524f72bbe1fcf4cf5dab1b4deab555fe475f9291))
* **all:** Auto-regenerate discovery clients ([#2064](https://github.com/googleapis/google-api-go-client/issues/2064)) ([f391921](https://github.com/googleapis/google-api-go-client/commit/f391921d617b0cbe678c23e88e9cc392eb061837))
* **gensupport:** Pass in headers via context ([#2052](https://github.com/googleapis/google-api-go-client/issues/2052)) ([c836da9](https://github.com/googleapis/google-api-go-client/commit/c836da93b5de7664c38ece2e54a7c9025acc1dc0))

## [0.130.0](https://github.com/googleapis/google-api-go-client/compare/v0.129.0...v0.130.0) (2023-07-05)


### Features

* **all:** Auto-regenerate discovery clients ([#2041](https://github.com/googleapis/google-api-go-client/issues/2041)) ([dc4d425](https://github.com/googleapis/google-api-go-client/commit/dc4d425ae1e31ef6a9c9736dd32adbc530e54baa))
* **all:** Auto-regenerate discovery clients ([#2043](https://github.com/googleapis/google-api-go-client/issues/2043)) ([7a8816b](https://github.com/googleapis/google-api-go-client/commit/7a8816b1c4c0a6ac0e36ae07bc1d6737c13e7a4d))
* **all:** Auto-regenerate discovery clients ([#2044](https://github.com/googleapis/google-api-go-client/issues/2044)) ([380eafd](https://github.com/googleapis/google-api-go-client/commit/380eafd8ae92e184a2621c9ae73bc967e6829fec))
* **all:** Auto-regenerate discovery clients ([#2045](https://github.com/googleapis/google-api-go-client/issues/2045)) ([50d3e98](https://github.com/googleapis/google-api-go-client/commit/50d3e988448442d7eada2a85ad37596388beaa48))
* **all:** Auto-regenerate discovery clients ([#2046](https://github.com/googleapis/google-api-go-client/issues/2046)) ([6711565](https://github.com/googleapis/google-api-go-client/commit/6711565d141865432607cc49f0bb08486d0a5812))
* **all:** Auto-regenerate discovery clients ([#2049](https://github.com/googleapis/google-api-go-client/issues/2049)) ([5e08be4](https://github.com/googleapis/google-api-go-client/commit/5e08be4f052b052c1d2e25f8f762d028c1527c4e))
* **all:** Auto-regenerate discovery clients ([#2050](https://github.com/googleapis/google-api-go-client/issues/2050)) ([d79dfc2](https://github.com/googleapis/google-api-go-client/commit/d79dfc2722ff39e5674d3d66bd86496b63dc8204))
* **all:** Auto-regenerate discovery clients ([#2051](https://github.com/googleapis/google-api-go-client/issues/2051)) ([5ec0817](https://github.com/googleapis/google-api-go-client/commit/5ec0817bc6a56f87b5727c9c845f0d30734469b0))

## [0.129.0](https://github.com/googleapis/google-api-go-client/compare/v0.128.0...v0.129.0) (2023-06-27)


### Features

* **all:** Auto-regenerate discovery clients ([#2028](https://github.com/googleapis/google-api-go-client/issues/2028)) ([922fc6a](https://github.com/googleapis/google-api-go-client/commit/922fc6a38962d441b49d8592d62b5b4c70354b7a))
* **all:** Auto-regenerate discovery clients ([#2030](https://github.com/googleapis/google-api-go-client/issues/2030)) ([3eb845f](https://github.com/googleapis/google-api-go-client/commit/3eb845f12832f5a8943983d54b4a23da38e6f0ba))
* **all:** Auto-regenerate discovery clients ([#2032](https://github.com/googleapis/google-api-go-client/issues/2032)) ([247ad09](https://github.com/googleapis/google-api-go-client/commit/247ad09c5eaa9c06208a1acd99ccbf3b41b5e8f4))
* **all:** Auto-regenerate discovery clients ([#2033](https://github.com/googleapis/google-api-go-client/issues/2033)) ([cc73573](https://github.com/googleapis/google-api-go-client/commit/cc73573e605b04cdaabb4bdfbc355d79c6fba8ba))
* **all:** Auto-regenerate discovery clients ([#2035](https://github.com/googleapis/google-api-go-client/issues/2035)) ([177408e](https://github.com/googleapis/google-api-go-client/commit/177408ea127ce2e5a171fa54008838560203e587))
* **all:** Auto-regenerate discovery clients ([#2040](https://github.com/googleapis/google-api-go-client/issues/2040)) ([5e1c531](https://github.com/googleapis/google-api-go-client/commit/5e1c531ef949b53a8997c25e3f4ea7943b3335b7))

## [0.128.0](https://github.com/googleapis/google-api-go-client/compare/v0.127.0...v0.128.0) (2023-06-15)


### Features

* **all:** Auto-regenerate discovery clients ([#2022](https://github.com/googleapis/google-api-go-client/issues/2022)) ([d846ea5](https://github.com/googleapis/google-api-go-client/commit/d846ea5dd79c01bbf7f2c116fa40b0bdcdc0dc1a))
* **all:** Auto-regenerate discovery clients ([#2026](https://github.com/googleapis/google-api-go-client/issues/2026)) ([58512c3](https://github.com/googleapis/google-api-go-client/commit/58512c3c782e9b42d0f215b1f46545686a07033f))
* **all:** Auto-regenerate discovery clients ([#2027](https://github.com/googleapis/google-api-go-client/issues/2027)) ([229def0](https://github.com/googleapis/google-api-go-client/commit/229def0dc32b86ab6524a4619189aece0b1ebbea))

## [0.127.0](https://github.com/googleapis/google-api-go-client/compare/v0.126.0...v0.127.0) (2023-06-12)


### Features

* **all:** Auto-regenerate discovery clients ([#2015](https://github.com/googleapis/google-api-go-client/issues/2015)) ([21af27f](https://github.com/googleapis/google-api-go-client/commit/21af27f16f65cdde5019e904a7f7fe67fc118dc1))
* **all:** Auto-regenerate discovery clients ([#2017](https://github.com/googleapis/google-api-go-client/issues/2017)) ([4c6e7c1](https://github.com/googleapis/google-api-go-client/commit/4c6e7c17ea4f5010c429638d6d0e007f45b09162))
* **all:** Auto-regenerate discovery clients ([#2018](https://github.com/googleapis/google-api-go-client/issues/2018)) ([c86a815](https://github.com/googleapis/google-api-go-client/commit/c86a8157d883e8cc0fb86669a111dd54656b24ac))
* **all:** Auto-regenerate discovery clients ([#2021](https://github.com/googleapis/google-api-go-client/issues/2021)) ([eb914ce](https://github.com/googleapis/google-api-go-client/commit/eb914ce613c6930b6908546e562090d4e30f879d))

## [0.126.0](https://github.com/googleapis/google-api-go-client/compare/v0.125.0...v0.126.0) (2023-06-08)


### Features

* **all:** Auto-regenerate discovery clients ([#2007](https://github.com/googleapis/google-api-go-client/issues/2007)) ([465e95b](https://github.com/googleapis/google-api-go-client/commit/465e95b0a0edfc30c6e3b4565ea85bc51afce578))
* **all:** Auto-regenerate discovery clients ([#2010](https://github.com/googleapis/google-api-go-client/issues/2010)) ([3dc0dbb](https://github.com/googleapis/google-api-go-client/commit/3dc0dbb9c8d0dbe6c50d503b96caa0a73a2145cc))
* **all:** Auto-regenerate discovery clients ([#2011](https://github.com/googleapis/google-api-go-client/issues/2011)) ([4fed5c2](https://github.com/googleapis/google-api-go-client/commit/4fed5c245895e756541e509887175cb8ade4adbf))
* **all:** Auto-regenerate discovery clients ([#2012](https://github.com/googleapis/google-api-go-client/issues/2012)) ([95d3fd1](https://github.com/googleapis/google-api-go-client/commit/95d3fd1747451b492deefe490ecc52842df0c031))

## [0.125.0](https://github.com/googleapis/google-api-go-client/compare/v0.124.0...v0.125.0) (2023-05-30)


### Features

* **all:** Auto-regenerate discovery clients ([#1995](https://github.com/googleapis/google-api-go-client/issues/1995)) ([cdcccfa](https://github.com/googleapis/google-api-go-client/commit/cdcccfa295910a1cd38694eca22d5a87689daf36))
* **all:** Auto-regenerate discovery clients ([#1998](https://github.com/googleapis/google-api-go-client/issues/1998)) ([f701782](https://github.com/googleapis/google-api-go-client/commit/f701782c8a1e0d9dacf0aeb899fd6f84da8b91d2))
* **all:** Auto-regenerate discovery clients ([#1999](https://github.com/googleapis/google-api-go-client/issues/1999)) ([85ab112](https://github.com/googleapis/google-api-go-client/commit/85ab112f15b4010426a4bfe9bddd69b8ee6e2b1f))
* **all:** Auto-regenerate discovery clients ([#2001](https://github.com/googleapis/google-api-go-client/issues/2001)) ([ed05294](https://github.com/googleapis/google-api-go-client/commit/ed052946a0e8821ca7ef42f92f59b7fb7574b622))
* **all:** Auto-regenerate discovery clients ([#2002](https://github.com/googleapis/google-api-go-client/issues/2002)) ([f18c4ed](https://github.com/googleapis/google-api-go-client/commit/f18c4edfa573284b52caf8859602d1349b7712c6))
* **all:** Auto-regenerate discovery clients ([#2004](https://github.com/googleapis/google-api-go-client/issues/2004)) ([37ce51c](https://github.com/googleapis/google-api-go-client/commit/37ce51c4fc6761d02f384d21e9291a5dc0b2b344))
* Update direct deps ([#2006](https://github.com/googleapis/google-api-go-client/issues/2006)) ([3e8621c](https://github.com/googleapis/google-api-go-client/commit/3e8621cc6d50c2e31fc94b6f89be0885ab724a0e))

## [0.124.0](https://github.com/googleapis/google-api-go-client/compare/v0.123.0...v0.124.0) (2023-05-23)


### Features

* **all:** Auto-regenerate discovery clients ([#1988](https://github.com/googleapis/google-api-go-client/issues/1988)) ([0b4f4af](https://github.com/googleapis/google-api-go-client/commit/0b4f4aff308792890dd6e196e57c5ab581148330))
* **all:** Auto-regenerate discovery clients ([#1991](https://github.com/googleapis/google-api-go-client/issues/1991)) ([73f57fe](https://github.com/googleapis/google-api-go-client/commit/73f57fe09cf5213f2e4979d645ba9669389e80ce))

## [0.123.0](https://github.com/googleapis/google-api-go-client/compare/v0.122.0...v0.123.0) (2023-05-18)


### Features

* **all:** Auto-regenerate discovery clients ([#1974](https://github.com/googleapis/google-api-go-client/issues/1974)) ([98b3073](https://github.com/googleapis/google-api-go-client/commit/98b3073cf54e98459fb5fbd049328360094fb71d))
* **all:** Auto-regenerate discovery clients ([#1978](https://github.com/googleapis/google-api-go-client/issues/1978)) ([d27f40f](https://github.com/googleapis/google-api-go-client/commit/d27f40fac5e279f65a3002bb55082453454e2ad7))
* **all:** Auto-regenerate discovery clients ([#1982](https://github.com/googleapis/google-api-go-client/issues/1982)) ([f31b763](https://github.com/googleapis/google-api-go-client/commit/f31b763e2a7354c9d908c61a183c53b0cbe43cb3))

## [0.122.0](https://github.com/googleapis/google-api-go-client/compare/v0.121.0...v0.122.0) (2023-05-09)


### Features

* **all:** Auto-regenerate discovery clients ([#1973](https://github.com/googleapis/google-api-go-client/issues/1973)) ([ab64815](https://github.com/googleapis/google-api-go-client/commit/ab64815cd796f5a7930d9bbf53b8c19ec2efca83))


### Bug Fixes

* Add better support of array of floats ([#1971](https://github.com/googleapis/google-api-go-client/issues/1971)) ([8b0974e](https://github.com/googleapis/google-api-go-client/commit/8b0974e59d252ca5a42629e9b77baadd226a4090))

## [0.121.0](https://github.com/googleapis/google-api-go-client/compare/v0.120.0...v0.121.0) (2023-05-03)


### Features

* **all:** Auto-regenerate discovery clients ([#1961](https://github.com/googleapis/google-api-go-client/issues/1961)) ([2068ba5](https://github.com/googleapis/google-api-go-client/commit/2068ba54f4826f8b5d28839e94c4bbf661e3da4e))
* **all:** Auto-regenerate discovery clients ([#1963](https://github.com/googleapis/google-api-go-client/issues/1963)) ([c2c2b59](https://github.com/googleapis/google-api-go-client/commit/c2c2b593d0755c1e69c5a669c2b1cbb490fb48c6))

## [0.120.0](https://github.com/googleapis/google-api-go-client/compare/v0.119.0...v0.120.0) (2023-04-25)


### Features

* **all:** Auto-regenerate discovery clients ([#1955](https://github.com/googleapis/google-api-go-client/issues/1955)) ([409bc9d](https://github.com/googleapis/google-api-go-client/commit/409bc9d50bd4e59d23ae097f5d5a435c8682e000))
* **all:** Auto-regenerate discovery clients ([#1957](https://github.com/googleapis/google-api-go-client/issues/1957)) ([289b859](https://github.com/googleapis/google-api-go-client/commit/289b8592f5aacfdbcdc6172d6b5ea937c245b152))
* **all:** Auto-regenerate discovery clients ([#1958](https://github.com/googleapis/google-api-go-client/issues/1958)) ([fcd007a](https://github.com/googleapis/google-api-go-client/commit/fcd007a04f77950981b384055e130667b6e275b7))
* **all:** Auto-regenerate discovery clients ([#1960](https://github.com/googleapis/google-api-go-client/issues/1960)) ([4e35cac](https://github.com/googleapis/google-api-go-client/commit/4e35cac233b9b53616da5ce45c997115fa3f8696))

## [0.119.0](https://github.com/googleapis/google-api-go-client/compare/v0.118.0...v0.119.0) (2023-04-19)


### Features

* Add an option to enable DirectPath xDS ([#1942](https://github.com/googleapis/google-api-go-client/issues/1942)) ([685ec81](https://github.com/googleapis/google-api-go-client/commit/685ec81a16c29f3ae9e487042f954ed59adb97df))
* **all:** Auto-regenerate discovery clients ([#1943](https://github.com/googleapis/google-api-go-client/issues/1943)) ([690068f](https://github.com/googleapis/google-api-go-client/commit/690068ff96fb835a881629868d069f117a983ea2))
* **all:** Auto-regenerate discovery clients ([#1947](https://github.com/googleapis/google-api-go-client/issues/1947)) ([a0dacd5](https://github.com/googleapis/google-api-go-client/commit/a0dacd59461bc796d54c387f666520a67806d14b))
* **all:** Auto-regenerate discovery clients ([#1948](https://github.com/googleapis/google-api-go-client/issues/1948)) ([e1eda57](https://github.com/googleapis/google-api-go-client/commit/e1eda577a094fc8ffd402c6dc28e95a2998d3010))
* **all:** Auto-regenerate discovery clients ([#1952](https://github.com/googleapis/google-api-go-client/issues/1952)) ([4cb8eb9](https://github.com/googleapis/google-api-go-client/commit/4cb8eb989d2783f5da2b37e8c75ef38eb59441bb))
* **all:** Auto-regenerate discovery clients ([#1953](https://github.com/googleapis/google-api-go-client/issues/1953)) ([d85769c](https://github.com/googleapis/google-api-go-client/commit/d85769c0ff0ffb1cea5215c66dadc30801621434))

## [0.118.0](https://github.com/googleapis/google-api-go-client/compare/v0.117.0...v0.118.0) (2023-04-12)


### Features

* **all:** Auto-regenerate discovery clients ([#1939](https://github.com/googleapis/google-api-go-client/issues/1939)) ([ac94a0f](https://github.com/googleapis/google-api-go-client/commit/ac94a0fb03cb3c8e41dce1a459157c83ceec82a9))
* **all:** Auto-regenerate discovery clients ([#1941](https://github.com/googleapis/google-api-go-client/issues/1941)) ([29dc45a](https://github.com/googleapis/google-api-go-client/commit/29dc45aeea5404991120dcf98ada41f452a2fb0c))

## [0.117.0](https://github.com/googleapis/google-api-go-client/compare/v0.116.0...v0.117.0) (2023-04-10)


### Features

* Add experimental s2a-go integration ([#1874](https://github.com/googleapis/google-api-go-client/issues/1874)) ([3c61729](https://github.com/googleapis/google-api-go-client/commit/3c617292b3eb2fde43a906276522a15c66a43477))
* **all:** Auto-regenerate discovery clients ([#1932](https://github.com/googleapis/google-api-go-client/issues/1932)) ([2efcb2e](https://github.com/googleapis/google-api-go-client/commit/2efcb2ef82ec93741b5a34f6ba89033c4c6ad829))
* **all:** Auto-regenerate discovery clients ([#1935](https://github.com/googleapis/google-api-go-client/issues/1935)) ([2219681](https://github.com/googleapis/google-api-go-client/commit/2219681f2d350d49b722fa3ad4460000d3052b30))
* **all:** Auto-regenerate discovery clients ([#1936](https://github.com/googleapis/google-api-go-client/issues/1936)) ([750c7c8](https://github.com/googleapis/google-api-go-client/commit/750c7c8bed8996cc39805590744f34201c8284e4))

## [0.116.0](https://github.com/googleapis/google-api-go-client/compare/v0.115.0...v0.116.0) (2023-04-05)


### Features

* **all:** Auto-regenerate discovery clients ([#1928](https://github.com/googleapis/google-api-go-client/issues/1928)) ([28c8cd5](https://github.com/googleapis/google-api-go-client/commit/28c8cd57fd282ee69c3d24439ebcca5c16729878))

## [0.115.0](https://github.com/googleapis/google-api-go-client/compare/v0.114.0...v0.115.0) (2023-04-04)


### Features

* **all:** Auto-regenerate discovery clients ([#1913](https://github.com/googleapis/google-api-go-client/issues/1913)) ([1c955e8](https://github.com/googleapis/google-api-go-client/commit/1c955e862f47f153c19a0c17592be0f4a9508d21))
* **all:** Auto-regenerate discovery clients ([#1923](https://github.com/googleapis/google-api-go-client/issues/1923)) ([8930f0e](https://github.com/googleapis/google-api-go-client/commit/8930f0e28aaa9537c8fdae9ec25114940f423f6b))
* **all:** Auto-regenerate discovery clients ([#1924](https://github.com/googleapis/google-api-go-client/issues/1924)) ([33a2dfe](https://github.com/googleapis/google-api-go-client/commit/33a2dfe4d7d6e2d64643133eda0c2b65858517ce))
* **all:** Auto-regenerate discovery clients ([#1927](https://github.com/googleapis/google-api-go-client/issues/1927)) ([34781cf](https://github.com/googleapis/google-api-go-client/commit/34781cf7bdc818065a5c7e00ab0f850fc0073ddd))

## [0.114.0](https://github.com/googleapis/google-api-go-client/compare/v0.113.0...v0.114.0) (2023-03-17)


### Features

* **all:** Auto-regenerate discovery clients ([#1907](https://github.com/googleapis/google-api-go-client/issues/1907)) ([2754ab4](https://github.com/googleapis/google-api-go-client/commit/2754ab420dcf1c48e9b383c87f7d224ef99abc2f))


### Bug Fixes

* Always reference the internal package. ([#1909](https://github.com/googleapis/google-api-go-client/issues/1909)) ([dc4b77d](https://github.com/googleapis/google-api-go-client/commit/dc4b77d54e86e5b32bce720cf144f5c8a2031011)), refs [#1908](https://github.com/googleapis/google-api-go-client/issues/1908)

## [0.113.0](https://github.com/googleapis/google-api-go-client/compare/v0.112.0...v0.113.0) (2023-03-15)


### Features

* **all:** Auto-regenerate discovery clients ([#1900](https://github.com/googleapis/google-api-go-client/issues/1900)) ([fc221ce](https://github.com/googleapis/google-api-go-client/commit/fc221ced8f967897a23fa585f918801c10a13b0d))
* **idtoken:** Add support for external_account ([#1897](https://github.com/googleapis/google-api-go-client/issues/1897)) ([64b6ee4](https://github.com/googleapis/google-api-go-client/commit/64b6ee4ccbd1b9a52eed972989e9b8117406613b))
* **transport:** Add support for setting quota project with envvar ([#1892](https://github.com/googleapis/google-api-go-client/issues/1892)) ([63c48a6](https://github.com/googleapis/google-api-go-client/commit/63c48a69a6be327f495ce18f47395989b92456a6))

## [0.112.0](https://github.com/googleapis/google-api-go-client/compare/v0.111.0...v0.112.0) (2023-03-09)


### Features

* **all:** Auto-regenerate discovery clients ([#1882](https://github.com/googleapis/google-api-go-client/issues/1882)) ([15808d7](https://github.com/googleapis/google-api-go-client/commit/15808d75b5bd798c88f692d07261e7667f69a4c0))
* **all:** Auto-regenerate discovery clients ([#1884](https://github.com/googleapis/google-api-go-client/issues/1884)) ([1aee5cd](https://github.com/googleapis/google-api-go-client/commit/1aee5cd1cb55192a4675682444d9e0a22dab55a0))
* **all:** Auto-regenerate discovery clients ([#1885](https://github.com/googleapis/google-api-go-client/issues/1885)) ([c886360](https://github.com/googleapis/google-api-go-client/commit/c8863600179ebf003ae0043f94ea095a732e2517))
* **all:** Auto-regenerate discovery clients ([#1887](https://github.com/googleapis/google-api-go-client/issues/1887)) ([5da4d6a](https://github.com/googleapis/google-api-go-client/commit/5da4d6ab7fa9a3d68743a9dd6f90ab6cd9ea9277))
* **all:** Auto-regenerate discovery clients ([#1893](https://github.com/googleapis/google-api-go-client/issues/1893)) ([e88ee8a](https://github.com/googleapis/google-api-go-client/commit/e88ee8ac45e49f73b275bce6924180c0f184f277))
* **all:** Auto-regenerate discovery clients ([#1896](https://github.com/googleapis/google-api-go-client/issues/1896)) ([9f18671](https://github.com/googleapis/google-api-go-client/commit/9f186713659dc989b56a801e556a563954ecb673))
* **all:** Auto-regenerate discovery clients ([#1898](https://github.com/googleapis/google-api-go-client/issues/1898)) ([89c274a](https://github.com/googleapis/google-api-go-client/commit/89c274a9077778e05b3c5e459fd8dbbb58ed4a86))

## [0.111.0](https://github.com/googleapis/google-api-go-client/compare/v0.110.0...v0.111.0) (2023-02-28)


### Features

* **all:** Auto-regenerate discovery clients ([#1859](https://github.com/googleapis/google-api-go-client/issues/1859)) ([ba3414e](https://github.com/googleapis/google-api-go-client/commit/ba3414e017e9aef77005014054ba02f1f686f601))
* **all:** Auto-regenerate discovery clients ([#1861](https://github.com/googleapis/google-api-go-client/issues/1861)) ([895105a](https://github.com/googleapis/google-api-go-client/commit/895105a40de858f4803460982c7092f132b47a89))
* **all:** Auto-regenerate discovery clients ([#1863](https://github.com/googleapis/google-api-go-client/issues/1863)) ([8b8b195](https://github.com/googleapis/google-api-go-client/commit/8b8b19548ff684556b8c775f97c87667963e1946))
* **all:** Auto-regenerate discovery clients ([#1866](https://github.com/googleapis/google-api-go-client/issues/1866)) ([7f5f40a](https://github.com/googleapis/google-api-go-client/commit/7f5f40a84267f1505be68dced7498f3890871415))
* **all:** Auto-regenerate discovery clients ([#1872](https://github.com/googleapis/google-api-go-client/issues/1872)) ([7d34d41](https://github.com/googleapis/google-api-go-client/commit/7d34d415a57f11eba00dfe1a3a7b8a8b9de687cd))
* **all:** Auto-regenerate discovery clients ([#1873](https://github.com/googleapis/google-api-go-client/issues/1873)) ([c02cff6](https://github.com/googleapis/google-api-go-client/commit/c02cff63add0cceb3aff031d50e3856705f551d8))
* **all:** Auto-regenerate discovery clients ([#1875](https://github.com/googleapis/google-api-go-client/issues/1875)) ([70d3954](https://github.com/googleapis/google-api-go-client/commit/70d39545895bb5da4d79e419e3789e7011c53489))

## [0.110.0](https://github.com/googleapis/google-api-go-client/compare/v0.109.0...v0.110.0) (2023-02-13)


### Features

* **all:** Auto-regenerate discovery clients ([#1838](https://github.com/googleapis/google-api-go-client/issues/1838)) ([4b4c9d4](https://github.com/googleapis/google-api-go-client/commit/4b4c9d468a78cae7a41cbcb14054999dfef31b80))
* **all:** Auto-regenerate discovery clients ([#1841](https://github.com/googleapis/google-api-go-client/issues/1841)) ([3fb8cdc](https://github.com/googleapis/google-api-go-client/commit/3fb8cdc9c2ddf336497bc36fd06fab43b2235d06))
* **all:** Auto-regenerate discovery clients ([#1850](https://github.com/googleapis/google-api-go-client/issues/1850)) ([8980266](https://github.com/googleapis/google-api-go-client/commit/89802661d011ff33e3d5988f0e894702eba9c009))
* **all:** Auto-regenerate discovery clients ([#1851](https://github.com/googleapis/google-api-go-client/issues/1851)) ([689f934](https://github.com/googleapis/google-api-go-client/commit/689f934fca8cc3f8be521e41ab1e270691441dde))


### Bug Fixes

* Improve error handling for enterprise certificate module ([#1848](https://github.com/googleapis/google-api-go-client/issues/1848)) ([3fb5b61](https://github.com/googleapis/google-api-go-client/commit/3fb5b6154399e00f030db5570673f4690c534ddf))
* **internal/gensupport:** Don't prematurely close timers ([#1856](https://github.com/googleapis/google-api-go-client/issues/1856)) ([8efd00d](https://github.com/googleapis/google-api-go-client/commit/8efd00d3a913d1c454622791d4bfaa23e1343d70))
* Update ECP dependency to v0.2.3 ([#1857](https://github.com/googleapis/google-api-go-client/issues/1857)) ([1147cb8](https://github.com/googleapis/google-api-go-client/commit/1147cb8a93dfcd0255280b43a7f011ac2cf6ddab))

## [0.109.0](https://github.com/googleapis/google-api-go-client/compare/v0.108.0...v0.109.0) (2023-01-31)


### Features

* **all:** Auto-regenerate discovery clients ([#1817](https://github.com/googleapis/google-api-go-client/issues/1817)) ([ba3ba78](https://github.com/googleapis/google-api-go-client/commit/ba3ba788b274e51d8d68a94252d9f29d45f0e7cc))
* **all:** Auto-regenerate discovery clients ([#1819](https://github.com/googleapis/google-api-go-client/issues/1819)) ([5935892](https://github.com/googleapis/google-api-go-client/commit/593589291e6121b30375820a8b6ee36fb5bac9cb))
* **all:** Auto-regenerate discovery clients ([#1821](https://github.com/googleapis/google-api-go-client/issues/1821)) ([884a246](https://github.com/googleapis/google-api-go-client/commit/884a24654f56bd2a7f9e049054fc63774f3769f8))
* **all:** Auto-regenerate discovery clients ([#1822](https://github.com/googleapis/google-api-go-client/issues/1822)) ([85d0224](https://github.com/googleapis/google-api-go-client/commit/85d022490dfa59e3ff0beed59115c864918f8e4a))
* **all:** Auto-regenerate discovery clients ([#1825](https://github.com/googleapis/google-api-go-client/issues/1825)) ([6aad438](https://github.com/googleapis/google-api-go-client/commit/6aad43898977685fbbf7b964ad5a7d9764cbcd3b))
* **all:** Auto-regenerate discovery clients ([#1826](https://github.com/googleapis/google-api-go-client/issues/1826)) ([50fc7c4](https://github.com/googleapis/google-api-go-client/commit/50fc7c423d3d904fa541fb2794e20dde0de8cdee))
* **all:** Auto-regenerate discovery clients ([#1828](https://github.com/googleapis/google-api-go-client/issues/1828)) ([a5d0daa](https://github.com/googleapis/google-api-go-client/commit/a5d0daae5c8deec101f338d3fe1bf27fd86f22f9))
* **all:** Auto-regenerate discovery clients ([#1836](https://github.com/googleapis/google-api-go-client/issues/1836)) ([c13cc35](https://github.com/googleapis/google-api-go-client/commit/c13cc35851d528f611acdebf3b57db6c6c184958))

## [0.108.0](https://github.com/googleapis/google-api-go-client/compare/v0.107.0...v0.108.0) (2023-01-18)


### Features

* **all:** Auto-regenerate discovery clients ([#1810](https://github.com/googleapis/google-api-go-client/issues/1810)) ([4df52d2](https://github.com/googleapis/google-api-go-client/commit/4df52d27c1f775acfe81b34a98fea352625da11a))
* **all:** Auto-regenerate discovery clients ([#1813](https://github.com/googleapis/google-api-go-client/issues/1813)) ([a12685c](https://github.com/googleapis/google-api-go-client/commit/a12685c5ae7f28825c4af091a49ad71d69e46205))
* **all:** Auto-regenerate discovery clients ([#1816](https://github.com/googleapis/google-api-go-client/issues/1816)) ([da48b9a](https://github.com/googleapis/google-api-go-client/commit/da48b9ae7467e36f5d664f0afc4b88f1db0f1e57))

## [0.107.0](https://github.com/googleapis/google-api-go-client/compare/v0.106.0...v0.107.0) (2023-01-12)


### Features

* **all:** Auto-regenerate discovery clients ([#1800](https://github.com/googleapis/google-api-go-client/issues/1800)) ([93de455](https://github.com/googleapis/google-api-go-client/commit/93de45545cb6714f94bc4c347e3d932519e1f36d))
* **all:** Auto-regenerate discovery clients ([#1804](https://github.com/googleapis/google-api-go-client/issues/1804)) ([935ef64](https://github.com/googleapis/google-api-go-client/commit/935ef64234ab657eb0187dda0c63e2fc951e087e))
* **all:** Auto-regenerate discovery clients ([#1807](https://github.com/googleapis/google-api-go-client/issues/1807)) ([de06921](https://github.com/googleapis/google-api-go-client/commit/de06921b721c4c359c805fdd43274197dc2c295a))
* **all:** Auto-regenerate discovery clients ([#1808](https://github.com/googleapis/google-api-go-client/issues/1808)) ([bcc345c](https://github.com/googleapis/google-api-go-client/commit/bcc345cfb7afb9b3173aa10f14bcaa64f6de1fc4))
* **all:** Auto-regenerate discovery clients ([#1809](https://github.com/googleapis/google-api-go-client/issues/1809)) ([d8084e4](https://github.com/googleapis/google-api-go-client/commit/d8084e4c8254d4553922e4b678f1e49aa51aedec))
* Re-enable integrations:v1 ([#1801](https://github.com/googleapis/google-api-go-client/issues/1801)) ([4dca4e0](https://github.com/googleapis/google-api-go-client/commit/4dca4e00ad5b16c8a06dec1c4ae9d3b5f917406a))


### Bug Fixes

* User Timers over time.After ([#1802](https://github.com/googleapis/google-api-go-client/issues/1802)) ([86e4009](https://github.com/googleapis/google-api-go-client/commit/86e40095d597922ca122df94d6d8244ded244e97)), refs [#1761](https://github.com/googleapis/google-api-go-client/issues/1761)

## [0.106.0](https://github.com/googleapis/google-api-go-client/compare/v0.105.0...v0.106.0) (2023-01-04)


### Features

* **all:** Auto-regenerate discovery clients ([#1784](https://github.com/googleapis/google-api-go-client/issues/1784)) ([a7f08e2](https://github.com/googleapis/google-api-go-client/commit/a7f08e2d1f5d4590ae0c6d66077f012bd18b5464))
* **all:** Auto-regenerate discovery clients ([#1788](https://github.com/googleapis/google-api-go-client/issues/1788)) ([9fb35f5](https://github.com/googleapis/google-api-go-client/commit/9fb35f5f5db837dc8aba5b742b63e1a837621f75))
* **all:** Auto-regenerate discovery clients ([#1790](https://github.com/googleapis/google-api-go-client/issues/1790)) ([7bd17b3](https://github.com/googleapis/google-api-go-client/commit/7bd17b38d39db0700ee20e5078cd4b7c8c3d3acb))
* **all:** Auto-regenerate discovery clients ([#1794](https://github.com/googleapis/google-api-go-client/issues/1794)) ([3944e86](https://github.com/googleapis/google-api-go-client/commit/3944e86684b39e05e27a17e66ed54873433c6ad4))
* **idtoken:** Add support for impersonated_service_account creds type ([#1792](https://github.com/googleapis/google-api-go-client/issues/1792)) ([f6dec99](https://github.com/googleapis/google-api-go-client/commit/f6dec99d014cc508d0374b666f2c325534a30bea)), refs [#873](https://github.com/googleapis/google-api-go-client/issues/873)
* **option/internaloption:** Add new EmbeddableAdapter option ([#1787](https://github.com/googleapis/google-api-go-client/issues/1787)) ([1569e5b](https://github.com/googleapis/google-api-go-client/commit/1569e5b294ad150050319c108bfbcade2180351b))


### Bug Fixes

* **idtoken:** Configure validator constructor to use no authentication ([#1789](https://github.com/googleapis/google-api-go-client/issues/1789)) ([b35900a](https://github.com/googleapis/google-api-go-client/commit/b35900aff148bb8446ca7e15ed0beb50d749d6c7)), refs [#1682](https://github.com/googleapis/google-api-go-client/issues/1682)

## [0.105.0](https://github.com/googleapis/google-api-go-client/compare/v0.104.0...v0.105.0) (2022-12-14)


### Features

* **all:** Auto-regenerate discovery clients ([#1773](https://github.com/googleapis/google-api-go-client/issues/1773)) ([37a2e41](https://github.com/googleapis/google-api-go-client/commit/37a2e41e92933254a8432f3b74ad1a16eae2c5ac))
* **all:** Auto-regenerate discovery clients ([#1777](https://github.com/googleapis/google-api-go-client/issues/1777)) ([5b02761](https://github.com/googleapis/google-api-go-client/commit/5b02761e99fbb41602d107af92a8dec393250321))
* **googleapi:** Add response headers to Error reported by CheckMediaResponse ([#1781](https://github.com/googleapis/google-api-go-client/issues/1781)) ([e4271df](https://github.com/googleapis/google-api-go-client/commit/e4271dfa222fea0fcf61fc5133c66e2e8d8f08b1))
* Support set null map entries for non-simple map values ([#1782](https://github.com/googleapis/google-api-go-client/issues/1782)) ([c58bf4c](https://github.com/googleapis/google-api-go-client/commit/c58bf4cfef76fcd9a377452b5c3cb84d5f20ce98))

## [0.104.0](https://github.com/googleapis/google-api-go-client/compare/v0.103.0...v0.104.0) (2022-12-07)


### Features

* **all:** Auto-regenerate discovery clients ([#1746](https://github.com/googleapis/google-api-go-client/issues/1746)) ([292129c](https://github.com/googleapis/google-api-go-client/commit/292129c681cb5e8f7dc66e499e477be5aec4a26e))
* **all:** Auto-regenerate discovery clients ([#1751](https://github.com/googleapis/google-api-go-client/issues/1751)) ([a657f19](https://github.com/googleapis/google-api-go-client/commit/a657f191681814da2c048118f02e5a85e9c9436b))
* **all:** Auto-regenerate discovery clients ([#1752](https://github.com/googleapis/google-api-go-client/issues/1752)) ([dd565a4](https://github.com/googleapis/google-api-go-client/commit/dd565a4a1b3867b4a1fe86ff9d8a633a6f3ba032))
* **all:** Auto-regenerate discovery clients ([#1753](https://github.com/googleapis/google-api-go-client/issues/1753)) ([e18b504](https://github.com/googleapis/google-api-go-client/commit/e18b5044ca349e4d5b4a3b1cd807fed7e1e0fd39))
* **all:** Auto-regenerate discovery clients ([#1755](https://github.com/googleapis/google-api-go-client/issues/1755)) ([caf7af0](https://github.com/googleapis/google-api-go-client/commit/caf7af030c55a39723c92c3d9ee66b7c6c1e5a04))
* **all:** Auto-regenerate discovery clients ([#1760](https://github.com/googleapis/google-api-go-client/issues/1760)) ([97a9846](https://github.com/googleapis/google-api-go-client/commit/97a98461099acaeccf04f64531ef7f06696e64fd))
* **all:** Auto-regenerate discovery clients ([#1766](https://github.com/googleapis/google-api-go-client/issues/1766)) ([3195ce1](https://github.com/googleapis/google-api-go-client/commit/3195ce1ad12642c558d76353328a0ad05173e608))
* **all:** Auto-regenerate discovery clients ([#1767](https://github.com/googleapis/google-api-go-client/issues/1767)) ([2b596d9](https://github.com/googleapis/google-api-go-client/commit/2b596d9f5bf651ba950d60378880ef98bf9f439f))
* **all:** Auto-regenerate discovery clients ([#1771](https://github.com/googleapis/google-api-go-client/issues/1771)) ([f819644](https://github.com/googleapis/google-api-go-client/commit/f8196440cbf05306c6f25dfe490e1a9069d44952))
* **transport:** De-experiment google-c2p resolver ([#1757](https://github.com/googleapis/google-api-go-client/issues/1757)) ([8d8f0a7](https://github.com/googleapis/google-api-go-client/commit/8d8f0a70d0bd6ba4daaa08370d1420f759ff7f9d))


### Bug Fixes

* **idtoken:** Increase MaxIdleConnsPerHost to 100 in NewClient ([#1754](https://github.com/googleapis/google-api-go-client/issues/1754)) ([629e217](https://github.com/googleapis/google-api-go-client/commit/629e217f768c719d047c87c7389fbf757a45d0b9)), refs [#1744](https://github.com/googleapis/google-api-go-client/issues/1744)
* **transport/grpc:** Separate resolution of creds and certs ([#1759](https://github.com/googleapis/google-api-go-client/issues/1759)) ([c213153](https://github.com/googleapis/google-api-go-client/commit/c213153d17a87e76a4f721076ddaed3ac8cb26c7))


### Documentation

* Document limitation of WithUserAgent ([#1747](https://github.com/googleapis/google-api-go-client/issues/1747)) ([567070f](https://github.com/googleapis/google-api-go-client/commit/567070f3835f9f4039ed121de7319f9cf5a5af6b))

## [0.103.0](https://github.com/googleapis/google-api-go-client/compare/v0.102.0...v0.103.0) (2022-11-08)


### Features

* **all:** Auto-regenerate discovery clients ([#1737](https://github.com/googleapis/google-api-go-client/issues/1737)) ([de99200](https://github.com/googleapis/google-api-go-client/commit/de9920088db16562740c31183eca6651f669e582))
* **all:** Auto-regenerate discovery clients ([#1739](https://github.com/googleapis/google-api-go-client/issues/1739)) ([bbd4259](https://github.com/googleapis/google-api-go-client/commit/bbd42597f4710f527f83fd900cb7f9e6706bc195))
* **all:** Auto-regenerate discovery clients ([#1743](https://github.com/googleapis/google-api-go-client/issues/1743)) ([4248dc3](https://github.com/googleapis/google-api-go-client/commit/4248dc3db6b32d00720293980fb8e845b684fbd8))
* **googleapi:** Inject gax apierror.APIError into googleapi.Error ([#1730](https://github.com/googleapis/google-api-go-client/issues/1730)) ([ee25e29](https://github.com/googleapis/google-api-go-client/commit/ee25e29fd586cde25a006504d0059194a90f19ac))
* Rm hard dep on x/sys ([#1742](https://github.com/googleapis/google-api-go-client/issues/1742)) ([9695aa1](https://github.com/googleapis/google-api-go-client/commit/9695aa13a084c1ad9857db4a6c12d57e13fc00dc))

## [0.102.0](https://github.com/googleapis/google-api-go-client/compare/v0.101.0...v0.102.0) (2022-11-02)


### Features

* **all:** Auto-regenerate discovery clients ([#1725](https://github.com/googleapis/google-api-go-client/issues/1725)) ([06360d8](https://github.com/googleapis/google-api-go-client/commit/06360d8f37b88e064a8a60788077f376b597d942))
* **all:** Auto-regenerate discovery clients ([#1727](https://github.com/googleapis/google-api-go-client/issues/1727)) ([1e1eab9](https://github.com/googleapis/google-api-go-client/commit/1e1eab98aac0e967a6c52b65fe9eb5a4d6d8a946))
* **all:** Auto-regenerate discovery clients ([#1734](https://github.com/googleapis/google-api-go-client/issues/1734)) ([ce57a67](https://github.com/googleapis/google-api-go-client/commit/ce57a67eddb98f3ccd21c1c01dfcb18df0d77009))
* Rely on new compute metadata module directly ([#1736](https://github.com/googleapis/google-api-go-client/issues/1736)) ([0528475](https://github.com/googleapis/google-api-go-client/commit/0528475d51393bb6e3244816d9c6ea8c16275677))

## [0.101.0](https://github.com/googleapis/google-api-go-client/compare/v0.100.0...v0.101.0) (2022-10-25)


### Features

* **all:** Auto-regenerate discovery clients ([#1718](https://github.com/googleapis/google-api-go-client/issues/1718)) ([453b81a](https://github.com/googleapis/google-api-go-client/commit/453b81ac138e6572e9d6a3373c033c5abbcefbcc))
* **all:** Auto-regenerate discovery clients ([#1720](https://github.com/googleapis/google-api-go-client/issues/1720)) ([9140608](https://github.com/googleapis/google-api-go-client/commit/91406081538e06ab580f59d6fba001dc34f8574a))
* **all:** Auto-regenerate discovery clients ([#1723](https://github.com/googleapis/google-api-go-client/issues/1723)) ([f4788b3](https://github.com/googleapis/google-api-go-client/commit/f4788b325bd76337216a54e02e49cec4e3ee6987))

## [0.100.0](https://github.com/googleapis/google-api-go-client/compare/v0.99.0...v0.100.0) (2022-10-18)


### Features

* **all:** Auto-regenerate discovery clients ([#1712](https://github.com/googleapis/google-api-go-client/issues/1712)) ([f9e15f2](https://github.com/googleapis/google-api-go-client/commit/f9e15f2159928974af1a2ec539e20f17f94aab4d))
* **all:** Auto-regenerate discovery clients ([#1717](https://github.com/googleapis/google-api-go-client/issues/1717)) ([f990a2a](https://github.com/googleapis/google-api-go-client/commit/f990a2af6cd6210c8764bbe273a575886ea97038))
* **internal/gensupport:** Remove DetermineContentType, use gax-go copy ([#1716](https://github.com/googleapis/google-api-go-client/issues/1716)) ([37f90e9](https://github.com/googleapis/google-api-go-client/commit/37f90e974e83f06962ac923c502cd1b405c7f0fb))


### Bug Fixes

* **idtoken:** Allow missing age in http response header ([#1715](https://github.com/googleapis/google-api-go-client/issues/1715)) ([b235b1f](https://github.com/googleapis/google-api-go-client/commit/b235b1f8c718be6b8f361074d371768617a3da3a))

## [0.99.0](https://github.com/googleapis/google-api-go-client/compare/v0.98.0...v0.99.0) (2022-10-14)


### Features

* **all:** Auto-regenerate discovery clients ([#1701](https://github.com/googleapis/google-api-go-client/issues/1701)) ([6b81c83](https://github.com/googleapis/google-api-go-client/commit/6b81c8355addd65f718bb9195e1c2356117e1a1b))

## [0.98.0](https://github.com/googleapis/google-api-go-client/compare/v0.97.0...v0.98.0) (2022-09-27)


### Features

* **all:** Auto-regenerate discovery clients ([#1696](https://github.com/googleapis/google-api-go-client/issues/1696)) ([aa775b4](https://github.com/googleapis/google-api-go-client/commit/aa775b41d2e419002d4e7e7a390745dd2d07110a))
* **all:** Auto-regenerate discovery clients ([#1699](https://github.com/googleapis/google-api-go-client/issues/1699)) ([25b7450](https://github.com/googleapis/google-api-go-client/commit/25b7450d0d9efc46d4095d827f597ac85bb8b5b4))

## [0.97.0](https://github.com/googleapis/google-api-go-client/compare/v0.96.0...v0.97.0) (2022-09-21)


### Features

* **all:** Auto-regenerate discovery clients ([#1693](https://github.com/googleapis/google-api-go-client/issues/1693)) ([a87400b](https://github.com/googleapis/google-api-go-client/commit/a87400be9341608f73e9ae1b5dbbecc7adfbf609))
* **all:** Auto-regenerate discovery clients ([#1695](https://github.com/googleapis/google-api-go-client/issues/1695)) ([b8f2556](https://github.com/googleapis/google-api-go-client/commit/b8f25561a76841c7549a358925eb7bfc2236465e))
* **internal/gensupport:** Wrap retry failures with context and prev error ([#1684](https://github.com/googleapis/google-api-go-client/issues/1684)) ([f427ee3](https://github.com/googleapis/google-api-go-client/commit/f427ee3edede981524c2ffb57fd2d8981f8cf8b4)), refs [#1685](https://github.com/googleapis/google-api-go-client/issues/1685)


### Bug Fixes

* Build script bash error ([#1697](https://github.com/googleapis/google-api-go-client/issues/1697)) ([6b0515b](https://github.com/googleapis/google-api-go-client/commit/6b0515bf05d8c62007748827eed486c607af483b))
* **gensupport:** Allow initial request for resumable uploads to retry w/ non-nil getBody ([#1690](https://github.com/googleapis/google-api-go-client/issues/1690)) ([2c3e863](https://github.com/googleapis/google-api-go-client/commit/2c3e8638afc6702dcba732a1aa07ccb33eb9304b))

## [0.96.0](https://github.com/googleapis/google-api-go-client/compare/v0.95.0...v0.96.0) (2022-09-14)


### Features

* **all:** Auto-regenerate discovery clients ([#1686](https://github.com/googleapis/google-api-go-client/issues/1686)) ([ce5ed41](https://github.com/googleapis/google-api-go-client/commit/ce5ed411756019b79c77e580670fccc8c08cccca))
* **all:** Auto-regenerate discovery clients ([#1688](https://github.com/googleapis/google-api-go-client/issues/1688)) ([bc29a6b](https://github.com/googleapis/google-api-go-client/commit/bc29a6b8a0489e88796d5a00d4c06769793ace0d))
* **all:** Auto-regenerate discovery clients ([#1689](https://github.com/googleapis/google-api-go-client/issues/1689)) ([e801e10](https://github.com/googleapis/google-api-go-client/commit/e801e1051020e6721f2217f5aa3a4064399115e1))


### Bug Fixes

* Upgrade version of golang.org/x/net ([#1692](https://github.com/googleapis/google-api-go-client/issues/1692)) ([0f7c1ed](https://github.com/googleapis/google-api-go-client/commit/0f7c1ed65ca2c6212f21e7fce20aa5ab9952bdbc)), refs [#1691](https://github.com/googleapis/google-api-go-client/issues/1691)

## [0.95.0](https://github.com/googleapis/google-api-go-client/compare/v0.94.0...v0.95.0) (2022-09-06)


### Features

* **all:** Auto-regenerate discovery clients ([#1677](https://github.com/googleapis/google-api-go-client/issues/1677)) ([8757dbf](https://github.com/googleapis/google-api-go-client/commit/8757dbf5811cc9f4092a8259d859c35ad3cc6442))
* **all:** Auto-regenerate discovery clients ([#1680](https://github.com/googleapis/google-api-go-client/issues/1680)) ([8c72fb3](https://github.com/googleapis/google-api-go-client/commit/8c72fb345fb6e377fa984053ca9c00aa0c3a0985))
* **option:** Officially deprecate ImpersonateCredentials ([#1683](https://github.com/googleapis/google-api-go-client/issues/1683)) ([9a84077](https://github.com/googleapis/google-api-go-client/commit/9a84077014f9a37335d29132e373b92adf49f904))

## [0.94.0](https://github.com/googleapis/google-api-go-client/compare/v0.93.0...v0.94.0) (2022-08-23)


### Features

* **all:** auto-regenerate discovery clients, refs [#1676](https://github.com/googleapis/google-api-go-client/issues/1676) [#1673](https://github.com/googleapis/google-api-go-client/issues/1673) [#1672](https://github.com/googleapis/google-api-go-client/issues/1672) [#1671](https://github.com/googleapis/google-api-go-client/issues/1671) [#1667](https://github.com/googleapis/google-api-go-client/issues/1667)


### Bug Fixes

* **storage:** *int64 instead of int64 for Age cond ([#1598](https://github.com/googleapis/google-api-go-client/issues/1598)) ([9ea025d](https://github.com/googleapis/google-api-go-client/commit/9ea025dcfe9b67a95e08f4ec94ed4fb6a9767b8c))


### Documentation

* **option:** clarify behavior of WithScopes ([#1670](https://github.com/googleapis/google-api-go-client/issues/1670)) ([07ceb9d](https://github.com/googleapis/google-api-go-client/commit/07ceb9d607c85ffaa5bea97be66cf9d426ec55bb)), refs [#1644](https://github.com/googleapis/google-api-go-client/issues/1644)

## [0.93.0](https://github.com/googleapis/google-api-go-client/compare/v0.92.0...v0.93.0) (2022-08-16)


### Features

* **all:** auto-regenerate discovery clients, refs [#1664](https://github.com/googleapis/google-api-go-client/issues/1664) [#1662](https://github.com/googleapis/google-api-go-client/issues/1662) [#1661](https://github.com/googleapis/google-api-go-client/issues/1661) [#1652](https://github.com/googleapis/google-api-go-client/issues/1652)
* **google-api-go-generator:** Change field PaymentState to pointer ([#1663](https://github.com/googleapis/google-api-go-client/issues/1663)) ([d6ee425](https://github.com/googleapis/google-api-go-client/commit/d6ee425a65668ee28ff97c6fb70f3497865d6572)), refs [#727](https://github.com/googleapis/google-api-go-client/issues/727)

## [0.92.0](https://github.com/googleapis/google-api-go-client/compare/v0.91.0...v0.92.0) (2022-08-10)


### Features

* **all:** auto-regenerate discovery clients, refs [#1649](https://github.com/googleapis/google-api-go-client/issues/1649) [#1646](https://github.com/googleapis/google-api-go-client/issues/1646) [#1645](https://github.com/googleapis/google-api-go-client/issues/1645) [#1643](https://github.com/googleapis/google-api-go-client/issues/1643) [#1641](https://github.com/googleapis/google-api-go-client/issues/1641)

## [0.91.0](https://github.com/googleapis/google-api-go-client/compare/v0.90.0...v0.91.0) (2022-08-01)


### Features

* **all:** auto-regenerate discovery clients, refs [#1639](https://github.com/googleapis/google-api-go-client/issues/1639) [#1637](https://github.com/googleapis/google-api-go-client/issues/1637)

## [0.90.0](https://github.com/googleapis/google-api-go-client/compare/v0.89.0...v0.90.0) (2022-07-28)


### Features

* **all:** auto-regenerate discovery clients, refs [#1635](https://github.com/googleapis/google-api-go-client/issues/1635) [#1634](https://github.com/googleapis/google-api-go-client/issues/1634) [#1632](https://github.com/googleapis/google-api-go-client/issues/1632)
* manual regen ([#1636](https://github.com/googleapis/google-api-go-client/issues/1636)) ([babdbd1](https://github.com/googleapis/google-api-go-client/commit/babdbd159a1e20c1b7d7e66504b2e2f1b8cf61ad))

## [0.89.0](https://github.com/googleapis/google-api-go-client/compare/v0.88.0...v0.89.0) (2022-07-26)


### Features

* **all:** auto-regenerate discovery clients, refs [#1631](https://github.com/googleapis/google-api-go-client/issues/1631) [#1630](https://github.com/googleapis/google-api-go-client/issues/1630) [#1629](https://github.com/googleapis/google-api-go-client/issues/1629) [#1627](https://github.com/googleapis/google-api-go-client/issues/1627) [#1625](https://github.com/googleapis/google-api-go-client/issues/1625)

## [0.88.0](https://github.com/googleapis/google-api-go-client/compare/v0.87.0...v0.88.0) (2022-07-19)


### Features

* **all:** auto-regenerate discovery clients, refs [#1624](https://github.com/googleapis/google-api-go-client/issues/1624) [#1622](https://github.com/googleapis/google-api-go-client/issues/1622) [#1620](https://github.com/googleapis/google-api-go-client/issues/1620) [#1619](https://github.com/googleapis/google-api-go-client/issues/1619) [#1616](https://github.com/googleapis/google-api-go-client/issues/1616)

## [0.87.0](https://github.com/googleapis/google-api-go-client/compare/v0.86.0...v0.87.0) (2022-07-12)


### Features

* **all:** auto-regenerate discovery clients, refs [#1614](https://github.com/googleapis/google-api-go-client/issues/1614) [#1613](https://github.com/googleapis/google-api-go-client/issues/1613) [#1612](https://github.com/googleapis/google-api-go-client/issues/1612) [#1611](https://github.com/googleapis/google-api-go-client/issues/1611) [#1608](https://github.com/googleapis/google-api-go-client/issues/1608) [#1606](https://github.com/googleapis/google-api-go-client/issues/1606) [#1604](https://github.com/googleapis/google-api-go-client/issues/1604)

## [0.86.0](https://github.com/googleapis/google-api-go-client/compare/v0.85.0...v0.86.0) (2022-06-28)


### Features

* **all:** auto-regenerate discovery clients, refs [#1603](https://github.com/googleapis/google-api-go-client/issues/1603) [#1601](https://github.com/googleapis/google-api-go-client/issues/1601) [#1600](https://github.com/googleapis/google-api-go-client/issues/1600) [#1599](https://github.com/googleapis/google-api-go-client/issues/1599) [#1596](https://github.com/googleapis/google-api-go-client/issues/1596)

## [0.85.0](https://github.com/googleapis/google-api-go-client/compare/v0.84.0...v0.85.0) (2022-06-21)


### Features

* **all:** auto-regenerate discovery clients, refs [#1593](https://github.com/googleapis/google-api-go-client/issues/1593) [#1592](https://github.com/googleapis/google-api-go-client/issues/1592) [#1589](https://github.com/googleapis/google-api-go-client/issues/1589) [#1586](https://github.com/googleapis/google-api-go-client/issues/1586)

## [0.84.0](https://github.com/googleapis/google-api-go-client/compare/v0.83.0...v0.84.0) (2022-06-14)


### Features

* **all:** auto-regenerate discovery clients, refs [#1584](https://github.com/googleapis/google-api-go-client/issues/1584) [#1581](https://github.com/googleapis/google-api-go-client/issues/1581) [#1580](https://github.com/googleapis/google-api-go-client/issues/1580) [#1576](https://github.com/googleapis/google-api-go-client/issues/1576) [#1574](https://github.com/googleapis/google-api-go-client/issues/1574)
* **transport:** Integrate with enterprise certificate proxy ([#1570](https://github.com/googleapis/google-api-go-client/issues/1570)) ([1d5389b](https://github.com/googleapis/google-api-go-client/commit/1d5389b15d7a4669049cc446eba90285c67a554f))

## [0.83.0](https://github.com/googleapis/google-api-go-client/compare/v0.82.0...v0.83.0) (2022-06-07)


### Features

* **all:** auto-regenerate discovery clients, refs [#1571](https://github.com/googleapis/google-api-go-client/issues/1571) [#1569](https://github.com/googleapis/google-api-go-client/issues/1569) [#1566](https://github.com/googleapis/google-api-go-client/issues/1566)

## [0.82.0](https://github.com/googleapis/google-api-go-client/compare/v0.81.0...v0.82.0) (2022-06-01)


### Features

* **all:** auto-regenerate discovery clients, refs [#1565](https://github.com/googleapis/google-api-go-client/issues/1565) [#1562](https://github.com/googleapis/google-api-go-client/issues/1562) [#1561](https://github.com/googleapis/google-api-go-client/issues/1561) [#1560](https://github.com/googleapis/google-api-go-client/issues/1560) [#1557](https://github.com/googleapis/google-api-go-client/issues/1557)

## [0.81.0](https://github.com/googleapis/google-api-go-client/compare/v0.80.0...v0.81.0) (2022-05-24)


### Features

* **all:** auto-regenerate discovery clients, refs [#1556](https://github.com/googleapis/google-api-go-client/issues/1556) [#1553](https://github.com/googleapis/google-api-go-client/issues/1553) [#1551](https://github.com/googleapis/google-api-go-client/issues/1551) [#1550](https://github.com/googleapis/google-api-go-client/issues/1550) [#1548](https://github.com/googleapis/google-api-go-client/issues/1548)

## [0.80.0](https://github.com/googleapis/google-api-go-client/compare/v0.79.0...v0.80.0) (2022-05-17)


### Features

* **all:** auto-regenerate discovery clients, refs [#1547](https://github.com/googleapis/google-api-go-client/issues/1547) [#1545](https://github.com/googleapis/google-api-go-client/issues/1545) [#1543](https://github.com/googleapis/google-api-go-client/issues/1543) [#1541](https://github.com/googleapis/google-api-go-client/issues/1541) [#1539](https://github.com/googleapis/google-api-go-client/issues/1539)

## [0.79.0](https://github.com/googleapis/google-api-go-client/compare/v0.78.0...v0.79.0) (2022-05-10)


### Features

* **all:** auto-regenerate discovery clients, refs [#1538](https://github.com/googleapis/google-api-go-client/issues/1538) [#1535](https://github.com/googleapis/google-api-go-client/issues/1535) [#1534](https://github.com/googleapis/google-api-go-client/issues/1534) [#1533](https://github.com/googleapis/google-api-go-client/issues/1533) [#1531](https://github.com/googleapis/google-api-go-client/issues/1531)

## [0.78.0](https://github.com/googleapis/google-api-go-client/compare/v0.77.0...v0.78.0) (2022-05-03)


### Features

* **all:** auto-regenerate discovery clients, refs [#1530](https://github.com/googleapis/google-api-go-client/issues/1530) [#1527](https://github.com/googleapis/google-api-go-client/issues/1527)

## [0.77.0](https://github.com/googleapis/google-api-go-client/compare/v0.76.0...v0.77.0) (2022-04-29)


### Features

* regen cloudcommerceprocurement v1 ([#1525](https://github.com/googleapis/google-api-go-client/issues/1525)) ([138823b](https://github.com/googleapis/google-api-go-client/commit/138823b86344b32485c692ef3fa4adff7d661825))

## [0.76.0](https://github.com/googleapis/google-api-go-client/compare/v0.75.0...v0.76.0) (2022-04-26)


### Features

* **all:** auto-regenerate discovery clients, refs [#1523](https://github.com/googleapis/google-api-go-client/issues/1523) [#1522](https://github.com/googleapis/google-api-go-client/issues/1522) [#1521](https://github.com/googleapis/google-api-go-client/issues/1521) [#1518](https://github.com/googleapis/google-api-go-client/issues/1518)

## [0.75.0](https://github.com/googleapis/google-api-go-client/compare/v0.74.0...v0.75.0) (2022-04-20)


### Features

* **all:** auto-regenerate discovery clients, refs [#1516](https://github.com/googleapis/google-api-go-client/issues/1516) [#1514](https://github.com/googleapis/google-api-go-client/issues/1514) [#1513](https://github.com/googleapis/google-api-go-client/issues/1513) [#1511](https://github.com/googleapis/google-api-go-client/issues/1511) [#1510](https://github.com/googleapis/google-api-go-client/issues/1510) [#1509](https://github.com/googleapis/google-api-go-client/issues/1509) [#1504](https://github.com/googleapis/google-api-go-client/issues/1504) [#1503](https://github.com/googleapis/google-api-go-client/issues/1503) [#1500](https://github.com/googleapis/google-api-go-client/issues/1500) [#1498](https://github.com/googleapis/google-api-go-client/issues/1498) [#1496](https://github.com/googleapis/google-api-go-client/issues/1496)
* **transport:** remove grpc version guard ([#1506](https://github.com/googleapis/google-api-go-client/issues/1506)) ([d349e85](https://github.com/googleapis/google-api-go-client/commit/d349e8569473af826a87ebbeff59c90455f8490f))

## [0.74.0](https://github.com/googleapis/google-api-go-client/compare/v0.73.0...v0.74.0) (2022-03-30)


### Features

* **all:** auto-regenerate discovery clients, refs [#1495](https://github.com/googleapis/google-api-go-client/issues/1495) [#1492](https://github.com/googleapis/google-api-go-client/issues/1492) [#1490](https://github.com/googleapis/google-api-go-client/issues/1490) [#1489](https://github.com/googleapis/google-api-go-client/issues/1489) [#1488](https://github.com/googleapis/google-api-go-client/issues/1488) [#1486](https://github.com/googleapis/google-api-go-client/issues/1486) [#1483](https://github.com/googleapis/google-api-go-client/issues/1483) [#1480](https://github.com/googleapis/google-api-go-client/issues/1480)
* re-enable playintegrity api generation ([#1482](https://github.com/googleapis/google-api-go-client/issues/1482)) ([d1de029](https://github.com/googleapis/google-api-go-client/commit/d1de029b37b7170628ca308874aad0c5b62bb6ff)), refs [#1479](https://github.com/googleapis/google-api-go-client/issues/1479)

## [0.73.0](https://github.com/googleapis/google-api-go-client/compare/v0.72.0...v0.73.0) (2022-03-15)


### Features

* **all:** auto-regenerate discovery clients, refs [#1477](https://github.com/googleapis/google-api-go-client/issues/1477)
* **all:** prefer using WithDefaultScope option internally ([#1476](https://github.com/googleapis/google-api-go-client/issues/1476)) ([0922a63](https://github.com/googleapis/google-api-go-client/commit/0922a63f2341bb10cb3c3085233fd4b6adaeac26))

## [0.72.0](https://github.com/googleapis/google-api-go-client/compare/v0.71.0...v0.72.0) (2022-03-14)


### Features

* **all:** auto-regenerate discovery clients, refs [#1474](https://github.com/googleapis/google-api-go-client/issues/1474) [#1472](https://github.com/googleapis/google-api-go-client/issues/1472) [#1470](https://github.com/googleapis/google-api-go-client/issues/1470)

## [0.71.0](https://github.com/googleapis/google-api-go-client/compare/v0.70.0...v0.71.0) (2022-03-08)


### Features

* **all:** auto-regenerate discovery clients, refs [#1469](https://github.com/googleapis/google-api-go-client/issues/1469) [#1467](https://github.com/googleapis/google-api-go-client/issues/1467) [#1466](https://github.com/googleapis/google-api-go-client/issues/1466) [#1465](https://github.com/googleapis/google-api-go-client/issues/1465) [#1464](https://github.com/googleapis/google-api-go-client/issues/1464) [#1463](https://github.com/googleapis/google-api-go-client/issues/1463) [#1457](https://github.com/googleapis/google-api-go-client/issues/1457) [#1455](https://github.com/googleapis/google-api-go-client/issues/1455) [#1453](https://github.com/googleapis/google-api-go-client/issues/1453)
* **internal/gensupport:** add net.ErrClosed to default retry ([#1462](https://github.com/googleapis/google-api-go-client/issues/1462)) ([33ba990](https://github.com/googleapis/google-api-go-client/commit/33ba990caa9a19720ff862d91b1226781aee94cd))

## [0.70.0](https://github.com/googleapis/google-api-go-client/compare/v0.69.0...v0.70.0) (2022-02-22)


### Features

* **all:** auto-regenerate discovery clients, refs [#1450](https://github.com/googleapis/google-api-go-client/issues/1450) [#1449](https://github.com/googleapis/google-api-go-client/issues/1449) [#1448](https://github.com/googleapis/google-api-go-client/issues/1448) [#1444](https://github.com/googleapis/google-api-go-client/issues/1444)
* **transport:** add an env variable to disable DirectPath ([#1447](https://github.com/googleapis/google-api-go-client/issues/1447)) ([7bce545](https://github.com/googleapis/google-api-go-client/commit/7bce545d91c0e7d4c51962634dd40de39605f369))

## [0.69.0](https://github.com/googleapis/google-api-go-client/compare/v0.68.0...v0.69.0) (2022-02-15)


### Features

* **all:** auto-regenerate discovery clients, refs [#1443](https://github.com/googleapis/google-api-go-client/issues/1443) [#1439](https://github.com/googleapis/google-api-go-client/issues/1439) [#1438](https://github.com/googleapis/google-api-go-client/issues/1438) [#1437](https://github.com/googleapis/google-api-go-client/issues/1437)
* bump grpc and x/net ([#1428](https://github.com/googleapis/google-api-go-client/issues/1428)) ([331bc9e](https://github.com/googleapis/google-api-go-client/commit/331bc9ececf37af4a07db7a6e00e67800b66a88a))


### Bug Fixes

* **gensupport:** cover ChunkRetryDeadline edge case ([#1430](https://github.com/googleapis/google-api-go-client/issues/1430)) ([ef89845](https://github.com/googleapis/google-api-go-client/commit/ef898456d14592574235bb839514bd549e1007ba))
* **internal/kokoro:** path to module root to run discogen ([#1433](https://github.com/googleapis/google-api-go-client/issues/1433)) ([4499c41](https://github.com/googleapis/google-api-go-client/commit/4499c413cda13a7a638b34205941cdf367c3ae1a))

## [0.68.0](https://github.com/googleapis/google-api-go-client/compare/v0.67.0...v0.68.0) (2022-02-08)


### Features

* **all:** auto-regenerate discovery clients, refs [#1422](https://github.com/googleapis/google-api-go-client/issues/1422) [#1419](https://github.com/googleapis/google-api-go-client/issues/1419)


### Bug Fixes

* **googleapi:** fill response headers in Error ([#1418](https://github.com/googleapis/google-api-go-client/issues/1418)) ([9eaba81](https://github.com/googleapis/google-api-go-client/commit/9eaba8162c40393aa8b1f6a2e45caa876fd8fa78))
* start reporting a meaningful version in headers ([#1426](https://github.com/googleapis/google-api-go-client/issues/1426)) ([f025530](https://github.com/googleapis/google-api-go-client/commit/f025530e20e2388dd726b99619236a8330b7169b))

## [0.67.0](https://github.com/googleapis/google-api-go-client/compare/v0.66.0...v0.67.0) (2022-02-03)


### Features

* **all:** auto-regenerate discovery clients, refs [#1416](https://github.com/googleapis/google-api-go-client/issues/1416) [#1415](https://github.com/googleapis/google-api-go-client/issues/1415) [#1410](https://github.com/googleapis/google-api-go-client/issues/1410)
* **gensupport:** per-chunk deadline configs ([#1414](https://github.com/googleapis/google-api-go-client/issues/1414)) ([c987a5b](https://github.com/googleapis/google-api-go-client/commit/c987a5bccb53c29eb344aad2b37f6209a8b256fd)), refs [#685](https://github.com/googleapis/google-api-go-client/issues/685)

## [0.66.0](https://github.com/googleapis/google-api-go-client/compare/v0.65.0...v0.66.0) (2022-01-28)


### Features

* **all:** auto-regenerate discovery clients, refs [#1408](https://github.com/googleapis/google-api-go-client/issues/1408) [#1407](https://github.com/googleapis/google-api-go-client/issues/1407) [#1406](https://github.com/googleapis/google-api-go-client/issues/1406) [#1405](https://github.com/googleapis/google-api-go-client/issues/1405) [#1404](https://github.com/googleapis/google-api-go-client/issues/1404) [#1394](https://github.com/googleapis/google-api-go-client/issues/1394)
* **internal/gensupport:** add 408 to default retry ([#1397](https://github.com/googleapis/google-api-go-client/issues/1397)) ([576ebbf](https://github.com/googleapis/google-api-go-client/commit/576ebbf87c60944a97ffd44a7f51851bff0e2bba))

## [0.65.0](https://github.com/googleapis/google-api-go-client/compare/v0.64.0...v0.65.0) (2022-01-11)


### Features

* **all:** auto-regenerate discovery clients, refs [#1391](https://github.com/googleapis/google-api-go-client/issues/1391) [#1390](https://github.com/googleapis/google-api-go-client/issues/1390) [#1388](https://github.com/googleapis/google-api-go-client/issues/1388) [#1387](https://github.com/googleapis/google-api-go-client/issues/1387) [#1385](https://github.com/googleapis/google-api-go-client/issues/1385)

## [0.64.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.63.0...v0.64.0) (2022-01-06)


### Features

* **all:** auto-regenerate discovery clients , refs [#1384](https://www.github.com/googleapis/google-api-go-client/issues/1384) [#1382](https://www.github.com/googleapis/google-api-go-client/issues/1382) [#1381](https://www.github.com/googleapis/google-api-go-client/issues/1381) [#1379](https://www.github.com/googleapis/google-api-go-client/issues/1379) [#1378](https://www.github.com/googleapis/google-api-go-client/issues/1378) [#1377](https://www.github.com/googleapis/google-api-go-client/issues/1377) [#1376](https://www.github.com/googleapis/google-api-go-client/issues/1376) [#1375](https://www.github.com/googleapis/google-api-go-client/issues/1375) [#1374](https://www.github.com/googleapis/google-api-go-client/issues/1374) [#1372](https://www.github.com/googleapis/google-api-go-client/issues/1372) [#1370](https://www.github.com/googleapis/google-api-go-client/issues/1370) [#1368](https://www.github.com/googleapis/google-api-go-client/issues/1368) [#1366](https://www.github.com/googleapis/google-api-go-client/issues/1366) [#1365](https://www.github.com/googleapis/google-api-go-client/issues/1365) [#1362](https://www.github.com/googleapis/google-api-go-client/issues/1362) [#1360](https://www.github.com/googleapis/google-api-go-client/issues/1360) [#1356](https://www.github.com/googleapis/google-api-go-client/issues/1356) [#1354](https://www.github.com/googleapis/google-api-go-client/issues/1354) [#1353](https://www.github.com/googleapis/google-api-go-client/issues/1353) [#1352](https://www.github.com/googleapis/google-api-go-client/issues/1352) [#1351](https://www.github.com/googleapis/google-api-go-client/issues/1351) [#1349](https://www.github.com/googleapis/google-api-go-client/issues/1349)
* **transport:** remove google-c2p dependence to DirectPath ([#1361](https://www.github.com/googleapis/google-api-go-client/issues/1361)) ([e84950f](https://www.github.com/googleapis/google-api-go-client/commit/e84950f3bcd523a61686c1ebc8b6b3690473e4b7)), refs [#1283](https://www.github.com/googleapis/google-api-go-client/issues/1283)


### Bug Fixes

* **internal/gensupport:** check ctx in chunk retry ([#1364](https://www.github.com/googleapis/google-api-go-client/issues/1364)) ([e10082d](https://www.github.com/googleapis/google-api-go-client/commit/e10082d2a7e24c66fbe83eb94f0b532882141698))
* **internal/gensupport:** Make SendRequestWithRetry check for canceled contexts twice ([#1359](https://www.github.com/googleapis/google-api-go-client/issues/1359)) ([520b227](https://www.github.com/googleapis/google-api-go-client/commit/520b227a148907db521d8264e254dff1d22e0fc1)), refs [#1358](https://www.github.com/googleapis/google-api-go-client/issues/1358)

## [0.63.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.62.0...v0.63.0) (2021-12-13)


### Features

* **all:** auto-regenerate discovery clients , refs [#1348](https://www.github.com/googleapis/google-api-go-client/issues/1348) [#1345](https://www.github.com/googleapis/google-api-go-client/issues/1345) [#1344](https://www.github.com/googleapis/google-api-go-client/issues/1344) [#1343](https://www.github.com/googleapis/google-api-go-client/issues/1343) [#1341](https://www.github.com/googleapis/google-api-go-client/issues/1341)
* **internal/gensupport:** add configurable retry ([#1324](https://www.github.com/googleapis/google-api-go-client/issues/1324)) ([8d2eca8](https://www.github.com/googleapis/google-api-go-client/commit/8d2eca842c7289b0b1d243f564af19645d2d6249))

## [0.62.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.61.0...v0.62.0) (2021-12-08)


### Features

* **all:** auto-regenerate discovery clients , refs [#1339](https://www.github.com/googleapis/google-api-go-client/issues/1339) [#1338](https://www.github.com/googleapis/google-api-go-client/issues/1338) [#1336](https://www.github.com/googleapis/google-api-go-client/issues/1336) [#1333](https://www.github.com/googleapis/google-api-go-client/issues/1333) [#1332](https://www.github.com/googleapis/google-api-go-client/issues/1332) [#1329](https://www.github.com/googleapis/google-api-go-client/issues/1329)
* **transport:** pass call credentials to grpc-go for DirectPath ([#1297](https://www.github.com/googleapis/google-api-go-client/issues/1297)) ([c06faf5](https://www.github.com/googleapis/google-api-go-client/commit/c06faf5ee58f90117105fd1099e0d52816dede59))

## [0.61.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.60.0...v0.61.0) (2021-12-02)


### Features

* **all:** auto-regenerate discovery clients , refs [#1327](https://www.github.com/googleapis/google-api-go-client/issues/1327) [#1325](https://www.github.com/googleapis/google-api-go-client/issues/1325) [#1323](https://www.github.com/googleapis/google-api-go-client/issues/1323) [#1320](https://www.github.com/googleapis/google-api-go-client/issues/1320) [#1318](https://www.github.com/googleapis/google-api-go-client/issues/1318) [#1317](https://www.github.com/googleapis/google-api-go-client/issues/1317) [#1314](https://www.github.com/googleapis/google-api-go-client/issues/1314) [#1313](https://www.github.com/googleapis/google-api-go-client/issues/1313) [#1312](https://www.github.com/googleapis/google-api-go-client/issues/1312) [#1311](https://www.github.com/googleapis/google-api-go-client/issues/1311) [#1310](https://www.github.com/googleapis/google-api-go-client/issues/1310) [#1308](https://www.github.com/googleapis/google-api-go-client/issues/1308) [#1306](https://www.github.com/googleapis/google-api-go-client/issues/1306) [#1305](https://www.github.com/googleapis/google-api-go-client/issues/1305) [#1302](https://www.github.com/googleapis/google-api-go-client/issues/1302) [#1300](https://www.github.com/googleapis/google-api-go-client/issues/1300) [#1299](https://www.github.com/googleapis/google-api-go-client/issues/1299) [#1296](https://www.github.com/googleapis/google-api-go-client/issues/1296) [#1295](https://www.github.com/googleapis/google-api-go-client/issues/1295) [#1294](https://www.github.com/googleapis/google-api-go-client/issues/1294) [#1293](https://www.github.com/googleapis/google-api-go-client/issues/1293) [#1292](https://www.github.com/googleapis/google-api-go-client/issues/1292) [#1291](https://www.github.com/googleapis/google-api-go-client/issues/1291) [#1290](https://www.github.com/googleapis/google-api-go-client/issues/1290) [#1289](https://www.github.com/googleapis/google-api-go-client/issues/1289) [#1288](https://www.github.com/googleapis/google-api-go-client/issues/1288) [#1287](https://www.github.com/googleapis/google-api-go-client/issues/1287) [#1286](https://www.github.com/googleapis/google-api-go-client/issues/1286) [#1284](https://www.github.com/googleapis/google-api-go-client/issues/1284) [#1282](https://www.github.com/googleapis/google-api-go-client/issues/1282) [#1281](https://www.github.com/googleapis/google-api-go-client/issues/1281) [#1280](https://www.github.com/googleapis/google-api-go-client/issues/1280) [#1279](https://www.github.com/googleapis/google-api-go-client/issues/1279) [#1278](https://www.github.com/googleapis/google-api-go-client/issues/1278) [#1276](https://www.github.com/googleapis/google-api-go-client/issues/1276)

## [0.60.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.59.0...v0.60.0) (2021-10-28)


### Features

* **all:** auto-regenerate discovery clients , refs [#1274](https://www.github.com/googleapis/google-api-go-client/issues/1274) [#1273](https://www.github.com/googleapis/google-api-go-client/issues/1273) [#1272](https://www.github.com/googleapis/google-api-go-client/issues/1272) [#1271](https://www.github.com/googleapis/google-api-go-client/issues/1271) [#1268](https://www.github.com/googleapis/google-api-go-client/issues/1268) [#1266](https://www.github.com/googleapis/google-api-go-client/issues/1266) [#1265](https://www.github.com/googleapis/google-api-go-client/issues/1265) [#1262](https://www.github.com/googleapis/google-api-go-client/issues/1262)
* **transport:** add google-c2p dependence to DirectPath ([#1260](https://www.github.com/googleapis/google-api-go-client/issues/1260)) ([aa0f0be](https://www.github.com/googleapis/google-api-go-client/commit/aa0f0be70f2d6003c6d25b0852ba754bc12cba34))

## [0.59.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.58.0...v0.59.0) (2021-10-20)


### Features

* **all:** auto-regenerate discovery clients , refs [#1249](https://www.github.com/googleapis/google-api-go-client/issues/1249) [#1248](https://www.github.com/googleapis/google-api-go-client/issues/1248) [#1246](https://www.github.com/googleapis/google-api-go-client/issues/1246)

## [0.58.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.57.0...v0.58.0) (2021-09-28)


### Features

* **all:** auto-regenerate discovery clients , refs [#1244](https://www.github.com/googleapis/google-api-go-client/issues/1244) [#1242](https://www.github.com/googleapis/google-api-go-client/issues/1242) [#1241](https://www.github.com/googleapis/google-api-go-client/issues/1241) [#1239](https://www.github.com/googleapis/google-api-go-client/issues/1239) [#1238](https://www.github.com/googleapis/google-api-go-client/issues/1238) [#1236](https://www.github.com/googleapis/google-api-go-client/issues/1236) [#1235](https://www.github.com/googleapis/google-api-go-client/issues/1235) [#1234](https://www.github.com/googleapis/google-api-go-client/issues/1234) [#1232](https://www.github.com/googleapis/google-api-go-client/issues/1232) [#1231](https://www.github.com/googleapis/google-api-go-client/issues/1231) [#1227](https://www.github.com/googleapis/google-api-go-client/issues/1227)

## [0.57.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.56.0...v0.57.0) (2021-09-16)


### Features

* **all:** auto-regenerate discovery clients , refs [#1226](https://www.github.com/googleapis/google-api-go-client/issues/1226) [#1225](https://www.github.com/googleapis/google-api-go-client/issues/1225) [#1223](https://www.github.com/googleapis/google-api-go-client/issues/1223) [#1222](https://www.github.com/googleapis/google-api-go-client/issues/1222) [#1220](https://www.github.com/googleapis/google-api-go-client/issues/1220) [#1219](https://www.github.com/googleapis/google-api-go-client/issues/1219) [#1218](https://www.github.com/googleapis/google-api-go-client/issues/1218) [#1217](https://www.github.com/googleapis/google-api-go-client/issues/1217) [#1215](https://www.github.com/googleapis/google-api-go-client/issues/1215) [#1212](https://www.github.com/googleapis/google-api-go-client/issues/1212) [#1211](https://www.github.com/googleapis/google-api-go-client/issues/1211) [#1209](https://www.github.com/googleapis/google-api-go-client/issues/1209) [#1208](https://www.github.com/googleapis/google-api-go-client/issues/1208) [#1206](https://www.github.com/googleapis/google-api-go-client/issues/1206) [#1203](https://www.github.com/googleapis/google-api-go-client/issues/1203) [#1201](https://www.github.com/googleapis/google-api-go-client/issues/1201)

## [0.56.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.55.0...v0.56.0) (2021-08-31)


### Features

* **all:** auto-regenerate discovery clients , refs [#1199](https://www.github.com/googleapis/google-api-go-client/issues/1199)
* **option:** add internaloption to force use of certain credential ([#1162](https://www.github.com/googleapis/google-api-go-client/issues/1162)) ([62f4bc9](https://www.github.com/googleapis/google-api-go-client/commit/62f4bc9cc6c081a5e30c360dce098e5d8f55050f))

## [0.55.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.54.0...v0.55.0) (2021-08-30)


### Features

* **all:** auto-regenerate discovery clients , refs [#1195](https://www.github.com/googleapis/google-api-go-client/issues/1195) [#1191](https://www.github.com/googleapis/google-api-go-client/issues/1191) [#1190](https://www.github.com/googleapis/google-api-go-client/issues/1190) [#1189](https://www.github.com/googleapis/google-api-go-client/issues/1189) [#1188](https://www.github.com/googleapis/google-api-go-client/issues/1188) [#1183](https://www.github.com/googleapis/google-api-go-client/issues/1183) [#1181](https://www.github.com/googleapis/google-api-go-client/issues/1181) [#1180](https://www.github.com/googleapis/google-api-go-client/issues/1180) [#1175](https://www.github.com/googleapis/google-api-go-client/issues/1175) [#1174](https://www.github.com/googleapis/google-api-go-client/issues/1174) [#1173](https://www.github.com/googleapis/google-api-go-client/issues/1173) [#1172](https://www.github.com/googleapis/google-api-go-client/issues/1172) [#1171](https://www.github.com/googleapis/google-api-go-client/issues/1171) [#1169](https://www.github.com/googleapis/google-api-go-client/issues/1169) [#1168](https://www.github.com/googleapis/google-api-go-client/issues/1168) [#1166](https://www.github.com/googleapis/google-api-go-client/issues/1166) [#1164](https://www.github.com/googleapis/google-api-go-client/issues/1164)
* **internaloption:** add AllowNonDefaultServiceAccount internaloption ([#1127](https://www.github.com/googleapis/google-api-go-client/issues/1127)) ([d713001](https://www.github.com/googleapis/google-api-go-client/commit/d71300120fdeff12fa2ecca866567989a67db946))


### Bug Fixes

* **idtoken:** provide default scope for cert endpoint ([#1198](https://www.github.com/googleapis/google-api-go-client/issues/1198)) ([7019080](https://www.github.com/googleapis/google-api-go-client/commit/701908002bf1b34e9bf88ca0c3d2191a39bed0d1)), refs [#1187](https://www.github.com/googleapis/google-api-go-client/issues/1187)
* **impersonate:** allow lifetimes up to 12 hours ([#1186](https://www.github.com/googleapis/google-api-go-client/issues/1186)) ([569c56b](https://www.github.com/googleapis/google-api-go-client/commit/569c56bc622d1256ef3d3c0bb9d76d69721ec981)), refs [#1185](https://www.github.com/googleapis/google-api-go-client/issues/1185)

## [0.54.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.53.0...v0.54.0) (2021-08-13)


### Features

* **all:** auto-regenerate discovery clients , refs [#1163](https://www.github.com/googleapis/google-api-go-client/issues/1163) [#1160](https://www.github.com/googleapis/google-api-go-client/issues/1160)

## [0.53.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.52.0...v0.53.0) (2021-08-11)


### Features

* **all:** auto-regenerate discovery clients , refs [#1159](https://www.github.com/googleapis/google-api-go-client/issues/1159) [#1157](https://www.github.com/googleapis/google-api-go-client/issues/1157) [#1154](https://www.github.com/googleapis/google-api-go-client/issues/1154) [#1152](https://www.github.com/googleapis/google-api-go-client/issues/1152) [#1151](https://www.github.com/googleapis/google-api-go-client/issues/1151) [#1150](https://www.github.com/googleapis/google-api-go-client/issues/1150) [#1149](https://www.github.com/googleapis/google-api-go-client/issues/1149) [#1147](https://www.github.com/googleapis/google-api-go-client/issues/1147) [#1146](https://www.github.com/googleapis/google-api-go-client/issues/1146) [#1145](https://www.github.com/googleapis/google-api-go-client/issues/1145) [#1142](https://www.github.com/googleapis/google-api-go-client/issues/1142) [#1140](https://www.github.com/googleapis/google-api-go-client/issues/1140) [#1138](https://www.github.com/googleapis/google-api-go-client/issues/1138)
* **googleapi:** support setting arbitrary query parameters ([#1123](https://www.github.com/googleapis/google-api-go-client/issues/1123)) ([8085c66](https://www.github.com/googleapis/google-api-go-client/commit/8085c66486a521065a7e56a2e326c8de241930f5)), refs [#550](https://www.github.com/googleapis/google-api-go-client/issues/550)

## [0.52.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.51.0...v0.52.0) (2021-07-29)


### Features

* **all:** auto-regenerate discovery clients , refs [#1137](https://www.github.com/googleapis/google-api-go-client/issues/1137) [#1135](https://www.github.com/googleapis/google-api-go-client/issues/1135) [#1134](https://www.github.com/googleapis/google-api-go-client/issues/1134) [#1133](https://www.github.com/googleapis/google-api-go-client/issues/1133) [#1131](https://www.github.com/googleapis/google-api-go-client/issues/1131) [#1130](https://www.github.com/googleapis/google-api-go-client/issues/1130) [#1128](https://www.github.com/googleapis/google-api-go-client/issues/1128)

## [0.51.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.50.0...v0.51.0) (2021-07-22)


### Features

* **all:** auto-regenerate discovery clients , refs [#1126](https://www.github.com/googleapis/google-api-go-client/issues/1126) [#1125](https://www.github.com/googleapis/google-api-go-client/issues/1125) [#1122](https://www.github.com/googleapis/google-api-go-client/issues/1122) [#1121](https://www.github.com/googleapis/google-api-go-client/issues/1121) [#1119](https://www.github.com/googleapis/google-api-go-client/issues/1119) [#1118](https://www.github.com/googleapis/google-api-go-client/issues/1118) [#1116](https://www.github.com/googleapis/google-api-go-client/issues/1116) [#1115](https://www.github.com/googleapis/google-api-go-client/issues/1115) [#1114](https://www.github.com/googleapis/google-api-go-client/issues/1114) [#1113](https://www.github.com/googleapis/google-api-go-client/issues/1113) [#1112](https://www.github.com/googleapis/google-api-go-client/issues/1112) [#1110](https://www.github.com/googleapis/google-api-go-client/issues/1110) [#1109](https://www.github.com/googleapis/google-api-go-client/issues/1109) [#1108](https://www.github.com/googleapis/google-api-go-client/issues/1108) [#1107](https://www.github.com/googleapis/google-api-go-client/issues/1107) [#1106](https://www.github.com/googleapis/google-api-go-client/issues/1106) [#1105](https://www.github.com/googleapis/google-api-go-client/issues/1105) [#1104](https://www.github.com/googleapis/google-api-go-client/issues/1104) [#1102](https://www.github.com/googleapis/google-api-go-client/issues/1102) [#1101](https://www.github.com/googleapis/google-api-go-client/issues/1101) [#1100](https://www.github.com/googleapis/google-api-go-client/issues/1100) [#1098](https://www.github.com/googleapis/google-api-go-client/issues/1098)

## [0.50.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.49.0...v0.50.0) (2021-06-30)


### Features

* **all:** auto-regenerate discovery clients , refs [#1097](https://www.github.com/googleapis/google-api-go-client/issues/1097) [#1095](https://www.github.com/googleapis/google-api-go-client/issues/1095) [#1093](https://www.github.com/googleapis/google-api-go-client/issues/1093) [#1090](https://www.github.com/googleapis/google-api-go-client/issues/1090) [#1089](https://www.github.com/googleapis/google-api-go-client/issues/1089) [#1088](https://www.github.com/googleapis/google-api-go-client/issues/1088) [#1086](https://www.github.com/googleapis/google-api-go-client/issues/1086)


### Bug Fixes

* **internal:** fix self-signed detection with scopes ([#1096](https://www.github.com/googleapis/google-api-go-client/issues/1096)) ([ff1d20b](https://www.github.com/googleapis/google-api-go-client/commit/ff1d20ba85c66fcaed1c1e466fbc647e09339854)), refs [#1092](https://www.github.com/googleapis/google-api-go-client/issues/1092)

## [0.49.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.48.0...v0.49.0) (2021-06-23)


### Features

* **all:** auto-regenerate discovery clients , refs [#1085](https://www.github.com/googleapis/google-api-go-client/issues/1085) [#1084](https://www.github.com/googleapis/google-api-go-client/issues/1084) [#1082](https://www.github.com/googleapis/google-api-go-client/issues/1082) [#1080](https://www.github.com/googleapis/google-api-go-client/issues/1080) [#1079](https://www.github.com/googleapis/google-api-go-client/issues/1079) [#1078](https://www.github.com/googleapis/google-api-go-client/issues/1078) [#1076](https://www.github.com/googleapis/google-api-go-client/issues/1076) [#1073](https://www.github.com/googleapis/google-api-go-client/issues/1073) [#1071](https://www.github.com/googleapis/google-api-go-client/issues/1071) [#1070](https://www.github.com/googleapis/google-api-go-client/issues/1070) [#1068](https://www.github.com/googleapis/google-api-go-client/issues/1068) [#1067](https://www.github.com/googleapis/google-api-go-client/issues/1067) [#1066](https://www.github.com/googleapis/google-api-go-client/issues/1066) [#1064](https://www.github.com/googleapis/google-api-go-client/issues/1064) [#1063](https://www.github.com/googleapis/google-api-go-client/issues/1063) [#1060](https://www.github.com/googleapis/google-api-go-client/issues/1060)
* **internal:** [AIP-4111] support scopes for self-signed JWT auth flow ([#1075](https://www.github.com/googleapis/google-api-go-client/issues/1075)) ([29cab68](https://www.github.com/googleapis/google-api-go-client/commit/29cab68ebd5b9ca017503baf46d91a29f8e84716))

## [0.48.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.47.0...v0.48.0) (2021-06-07)


### Features

* **all:** auto-regenerate discovery clients , refs [#1059](https://www.github.com/googleapis/google-api-go-client/issues/1059) [#1057](https://www.github.com/googleapis/google-api-go-client/issues/1057) [#1056](https://www.github.com/googleapis/google-api-go-client/issues/1056) [#1054](https://www.github.com/googleapis/google-api-go-client/issues/1054) [#1053](https://www.github.com/googleapis/google-api-go-client/issues/1053) [#1052](https://www.github.com/googleapis/google-api-go-client/issues/1052) [#1051](https://www.github.com/googleapis/google-api-go-client/issues/1051) [#1050](https://www.github.com/googleapis/google-api-go-client/issues/1050) [#1046](https://www.github.com/googleapis/google-api-go-client/issues/1046) [#1045](https://www.github.com/googleapis/google-api-go-client/issues/1045) [#1044](https://www.github.com/googleapis/google-api-go-client/issues/1044) [#1043](https://www.github.com/googleapis/google-api-go-client/issues/1043) [#1042](https://www.github.com/googleapis/google-api-go-client/issues/1042) [#1039](https://www.github.com/googleapis/google-api-go-client/issues/1039) [#1033](https://www.github.com/googleapis/google-api-go-client/issues/1033) [#1032](https://www.github.com/googleapis/google-api-go-client/issues/1032) [#1030](https://www.github.com/googleapis/google-api-go-client/issues/1030)


### Bug Fixes

* **transport:** perform mTLS endpoint switching when custom http client is provided ([#1038](https://www.github.com/googleapis/google-api-go-client/issues/1038)) ([c07165f](https://www.github.com/googleapis/google-api-go-client/commit/c07165fb384c6107778c7b54116c92188821f9e5))

## [0.47.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.46.0...v0.47.0) (2021-05-19)


### Features

* **all:** auto-regenerate discovery clients , refs [#1029](https://www.github.com/googleapis/google-api-go-client/issues/1029) [#1027](https://www.github.com/googleapis/google-api-go-client/issues/1027) [#1026](https://www.github.com/googleapis/google-api-go-client/issues/1026) [#1024](https://www.github.com/googleapis/google-api-go-client/issues/1024) [#1023](https://www.github.com/googleapis/google-api-go-client/issues/1023) [#1022](https://www.github.com/googleapis/google-api-go-client/issues/1022) [#1021](https://www.github.com/googleapis/google-api-go-client/issues/1021) [#1018](https://www.github.com/googleapis/google-api-go-client/issues/1018) [#1017](https://www.github.com/googleapis/google-api-go-client/issues/1017) [#1015](https://www.github.com/googleapis/google-api-go-client/issues/1015) [#1013](https://www.github.com/googleapis/google-api-go-client/issues/1013) [#1012](https://www.github.com/googleapis/google-api-go-client/issues/1012) [#1011](https://www.github.com/googleapis/google-api-go-client/issues/1011) [#1009](https://www.github.com/googleapis/google-api-go-client/issues/1009) [#1008](https://www.github.com/googleapis/google-api-go-client/issues/1008) [#1005](https://www.github.com/googleapis/google-api-go-client/issues/1005)


### Bug Fixes

* **transport:** increase ReadIdleTimeout ([#1028](https://www.github.com/googleapis/google-api-go-client/issues/1028)) ([b3cd013](https://www.github.com/googleapis/google-api-go-client/commit/b3cd013353079b19a61d4e5a89c3385c586ddbad))

## [0.46.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.45.0...v0.46.0) (2021-05-03)

### Notice

As a part of the changes that were made in #927 it is now recommended that all impersonation
is done with the new impersonate package. Existing users of the experimental [option.ImpersonateCredentials](https://pkg.go.dev/google.golang.org/api/option#ImpersonateCredentials)
should consider migrating code to use this new package. See [this example](https://pkg.go.dev/google.golang.org/api/impersonate#example-CredentialsTokenSource-ServiceAccount)
for usage of the new package.

### Features

* add impersonate package ([#927](https://www.github.com/googleapis/google-api-go-client/issues/927)) ([#991](https://www.github.com/googleapis/google-api-go-client/issues/991)) ([4f8e0b2](https://www.github.com/googleapis/google-api-go-client/commit/4f8e0b2cef08407ea8e0ef389bd002240f99a318))
* **all:** auto-regenerate discovery clients , refs [#1004](https://www.github.com/googleapis/google-api-go-client/issues/1004) [#1001](https://www.github.com/googleapis/google-api-go-client/issues/1001) [#1000](https://www.github.com/googleapis/google-api-go-client/issues/1000) [#999](https://www.github.com/googleapis/google-api-go-client/issues/999) [#998](https://www.github.com/googleapis/google-api-go-client/issues/998) [#996](https://www.github.com/googleapis/google-api-go-client/issues/996) [#993](https://www.github.com/googleapis/google-api-go-client/issues/993) [#992](https://www.github.com/googleapis/google-api-go-client/issues/992) [#990](https://www.github.com/googleapis/google-api-go-client/issues/990) [#988](https://www.github.com/googleapis/google-api-go-client/issues/988)

## [0.45.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.44.0...v0.45.0) (2021-04-20)


### Features

* **all:** auto-regenerate discovery clients , refs [#979](https://www.github.com/googleapis/google-api-go-client/issues/979) [#977](https://www.github.com/googleapis/google-api-go-client/issues/977) [#976](https://www.github.com/googleapis/google-api-go-client/issues/976) [#974](https://www.github.com/googleapis/google-api-go-client/issues/974)
* **transport:** configure HTTP/2 ReadIdleTimeout ([#882](https://www.github.com/googleapis/google-api-go-client/issues/882)) ([c2ff762](https://www.github.com/googleapis/google-api-go-client/commit/c2ff762ec2c036284f19bba2b67b66d49c63a663))

## [0.44.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.43.0...v0.44.0) (2021-04-07)


### Features

* **all:** auto-regenerate discovery clients , refs [#972](https://www.github.com/googleapis/google-api-go-client/issues/972) [#971](https://www.github.com/googleapis/google-api-go-client/issues/971) [#969](https://www.github.com/googleapis/google-api-go-client/issues/969) [#970](https://www.github.com/googleapis/google-api-go-client/issues/970) [#968](https://www.github.com/googleapis/google-api-go-client/issues/968) [#967](https://www.github.com/googleapis/google-api-go-client/issues/967) [#966](https://www.github.com/googleapis/google-api-go-client/issues/966) [#965](https://www.github.com/googleapis/google-api-go-client/issues/965) [#963](https://www.github.com/googleapis/google-api-go-client/issues/963) [#959](https://www.github.com/googleapis/google-api-go-client/issues/959) [#956](https://www.github.com/googleapis/google-api-go-client/issues/956) [#955](https://www.github.com/googleapis/google-api-go-client/issues/955) [#954](https://www.github.com/googleapis/google-api-go-client/issues/954) [#953](https://www.github.com/googleapis/google-api-go-client/issues/953) [#951](https://www.github.com/googleapis/google-api-go-client/issues/951)


### Bug Fixes

* **compute:** make MetadataItems.Value a pointer ([#973](https://www.github.com/googleapis/google-api-go-client/issues/973)) ([d8cce34](https://www.github.com/googleapis/google-api-go-client/commit/d8cce341d63f52436ae62707841cb359cecb340a))

## [0.43.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.42.0...v0.43.0) (2021-03-24)


### Features

* **all:** auto-regenerate discovery clients , refs [#947](https://www.github.com/googleapis/google-api-go-client/issues/947) [#945](https://www.github.com/googleapis/google-api-go-client/issues/945) [#943](https://www.github.com/googleapis/google-api-go-client/issues/943) [#942](https://www.github.com/googleapis/google-api-go-client/issues/942) [#940](https://www.github.com/googleapis/google-api-go-client/issues/940) [#939](https://www.github.com/googleapis/google-api-go-client/issues/939) [#932](https://www.github.com/googleapis/google-api-go-client/issues/932) [#929](https://www.github.com/googleapis/google-api-go-client/issues/929)

## [0.42.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.41.0...v0.42.0) (2021-03-15)


### Features

* **all:** auto-regenerate discovery clients , refs [#925](https://www.github.com/googleapis/google-api-go-client/issues/925) [#923](https://www.github.com/googleapis/google-api-go-client/issues/923) [#922](https://www.github.com/googleapis/google-api-go-client/issues/922) [#920](https://www.github.com/googleapis/google-api-go-client/issues/920) [#918](https://www.github.com/googleapis/google-api-go-client/issues/918) [#916](https://www.github.com/googleapis/google-api-go-client/issues/916)

## [0.41.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.40.0...v0.41.0) (2021-03-09)


### Features

* **all:** auto-regenerate discovery clients , refs [#915](https://www.github.com/googleapis/google-api-go-client/issues/915) [#913](https://www.github.com/googleapis/google-api-go-client/issues/913) [#911](https://www.github.com/googleapis/google-api-go-client/issues/911) [#910](https://www.github.com/googleapis/google-api-go-client/issues/910) [#909](https://www.github.com/googleapis/google-api-go-client/issues/909) [#907](https://www.github.com/googleapis/google-api-go-client/issues/907) [#904](https://www.github.com/googleapis/google-api-go-client/issues/904) [#902](https://www.github.com/googleapis/google-api-go-client/issues/902) [#899](https://www.github.com/googleapis/google-api-go-client/issues/899) [#898](https://www.github.com/googleapis/google-api-go-client/issues/898) [#896](https://www.github.com/googleapis/google-api-go-client/issues/896) [#895](https://www.github.com/googleapis/google-api-go-client/issues/895) [#894](https://www.github.com/googleapis/google-api-go-client/issues/894) [#893](https://www.github.com/googleapis/google-api-go-client/issues/893) [#892](https://www.github.com/googleapis/google-api-go-client/issues/892) [#889](https://www.github.com/googleapis/google-api-go-client/issues/889) [#888](https://www.github.com/googleapis/google-api-go-client/issues/888) [#887](https://www.github.com/googleapis/google-api-go-client/issues/887) [#884](https://www.github.com/googleapis/google-api-go-client/issues/884) [#880](https://www.github.com/googleapis/google-api-go-client/issues/880) [#879](https://www.github.com/googleapis/google-api-go-client/issues/879) [#878](https://www.github.com/googleapis/google-api-go-client/issues/878) [#877](https://www.github.com/googleapis/google-api-go-client/issues/877) [#876](https://www.github.com/googleapis/google-api-go-client/issues/876) [#874](https://www.github.com/googleapis/google-api-go-client/issues/874)

## [0.40.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.39.0...v0.40.0) (2021-02-12)


### Features

* **all:** auto-regenerate discovery clients , refs [#872](https://www.github.com/googleapis/google-api-go-client/issues/872) [#871](https://www.github.com/googleapis/google-api-go-client/issues/871) [#869](https://www.github.com/googleapis/google-api-go-client/issues/869) [#866](https://www.github.com/googleapis/google-api-go-client/issues/866) [#865](https://www.github.com/googleapis/google-api-go-client/issues/865) [#863](https://www.github.com/googleapis/google-api-go-client/issues/863) [#862](https://www.github.com/googleapis/google-api-go-client/issues/862) [#859](https://www.github.com/googleapis/google-api-go-client/issues/859)

## [0.39.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.38.0...v0.39.0) (2021-02-04)


### Features

* **all:** auto-regenerate discovery clients , refs [#855](https://www.github.com/googleapis/google-api-go-client/issues/855) [#854](https://www.github.com/googleapis/google-api-go-client/issues/854) [#853](https://www.github.com/googleapis/google-api-go-client/issues/853) [#851](https://www.github.com/googleapis/google-api-go-client/issues/851) [#850](https://www.github.com/googleapis/google-api-go-client/issues/850) [#848](https://www.github.com/googleapis/google-api-go-client/issues/848)


### Bug Fixes

* **transport:** expand OS environment variables in cert provider command ([#852](https://www.github.com/googleapis/google-api-go-client/issues/852)) ([be6c56a](https://www.github.com/googleapis/google-api-go-client/commit/be6c56a1948a57eb0300613a70ef608330ca36e0))

## [0.38.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.37.0...v0.38.0) (2021-01-29)


### Features

* **all:** auto-regenerate discovery clients , refs [#846](https://www.github.com/googleapis/google-api-go-client/issues/846) [#845](https://www.github.com/googleapis/google-api-go-client/issues/845) [#844](https://www.github.com/googleapis/google-api-go-client/issues/844) [#840](https://www.github.com/googleapis/google-api-go-client/issues/840)


### Bug Fixes

* **internal:** don't self-sign JWT when an endpoint provided ([#847](https://www.github.com/googleapis/google-api-go-client/issues/847)) ([55f262c](https://www.github.com/googleapis/google-api-go-client/commit/55f262c3a4e8d287ceeeee844b0d174299acc439))
* **internal:** don't use self-signed JWT with impersonation ([#788](https://www.github.com/googleapis/google-api-go-client/issues/788)) ([1dc7dac](https://www.github.com/googleapis/google-api-go-client/commit/1dc7dacd54b4b93f5465b71f2ee8c27e59630454))

## [0.37.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.36.0...v0.37.0) (2021-01-25)


### Features

* **all:** auto-regenerate discovery clients , refs [#839](https://www.github.com/googleapis/google-api-go-client/issues/839) [#838](https://www.github.com/googleapis/google-api-go-client/issues/838) [#836](https://www.github.com/googleapis/google-api-go-client/issues/836) [#834](https://www.github.com/googleapis/google-api-go-client/issues/834) [#833](https://www.github.com/googleapis/google-api-go-client/issues/833) [#831](https://www.github.com/googleapis/google-api-go-client/issues/831) [#830](https://www.github.com/googleapis/google-api-go-client/issues/830) [#829](https://www.github.com/googleapis/google-api-go-client/issues/829) [#828](https://www.github.com/googleapis/google-api-go-client/issues/828) [#827](https://www.github.com/googleapis/google-api-go-client/issues/827) [#825](https://www.github.com/googleapis/google-api-go-client/issues/825) [#824](https://www.github.com/googleapis/google-api-go-client/issues/824) [#823](https://www.github.com/googleapis/google-api-go-client/issues/823) [#822](https://www.github.com/googleapis/google-api-go-client/issues/822) [#820](https://www.github.com/googleapis/google-api-go-client/issues/820) [#819](https://www.github.com/googleapis/google-api-go-client/issues/819) [#817](https://www.github.com/googleapis/google-api-go-client/issues/817) [#816](https://www.github.com/googleapis/google-api-go-client/issues/816) [#812](https://www.github.com/googleapis/google-api-go-client/issues/812) [#811](https://www.github.com/googleapis/google-api-go-client/issues/811) [#810](https://www.github.com/googleapis/google-api-go-client/issues/810) [#809](https://www.github.com/googleapis/google-api-go-client/issues/809) [#807](https://www.github.com/googleapis/google-api-go-client/issues/807) [#806](https://www.github.com/googleapis/google-api-go-client/issues/806) [#805](https://www.github.com/googleapis/google-api-go-client/issues/805) [#803](https://www.github.com/googleapis/google-api-go-client/issues/803) [#800](https://www.github.com/googleapis/google-api-go-client/issues/800) [#799](https://www.github.com/googleapis/google-api-go-client/issues/799) [#793](https://www.github.com/googleapis/google-api-go-client/issues/793) [#792](https://www.github.com/googleapis/google-api-go-client/issues/792) [#786](https://www.github.com/googleapis/google-api-go-client/issues/786) [#784](https://www.github.com/googleapis/google-api-go-client/issues/784) [#782](https://www.github.com/googleapis/google-api-go-client/issues/782) [#779](https://www.github.com/googleapis/google-api-go-client/issues/779) [#771](https://www.github.com/googleapis/google-api-go-client/issues/771) [#770](https://www.github.com/googleapis/google-api-go-client/issues/770) [#768](https://www.github.com/googleapis/google-api-go-client/issues/768)
* **transport/bytestream:** Add Close method for shutdown ([#787](https://www.github.com/googleapis/google-api-go-client/issues/787)) ([96bfd87](https://www.github.com/googleapis/google-api-go-client/commit/96bfd877fbc5869c0a4d87de4daeb1f76aaca79d)), refs [#775](https://www.github.com/googleapis/google-api-go-client/issues/775)


### Bug Fixes

* **all:** use CheckResponse for media downloads ([#773](https://www.github.com/googleapis/google-api-go-client/issues/773)) ([39cbab0](https://www.github.com/googleapis/google-api-go-client/commit/39cbab06d28f1d017bfc016c6735f6f45c51c90e)), refs [#752](https://www.github.com/googleapis/google-api-go-client/issues/752)
* **compute:** don't tigger linter for field named Deprecated ([#774](https://www.github.com/googleapis/google-api-go-client/issues/774)) ([d2bc921](https://www.github.com/googleapis/google-api-go-client/commit/d2bc921f997425bc267d8e4845286b0d67bbe1ef)), refs [#767](https://www.github.com/googleapis/google-api-go-client/issues/767)
* don't use markdown style links ([#789](https://www.github.com/googleapis/google-api-go-client/issues/789)) ([09ddacb](https://www.github.com/googleapis/google-api-go-client/commit/09ddacba9c3b45798fa309d3719638c754ec69a1)), refs [#712](https://www.github.com/googleapis/google-api-go-client/issues/712)
* **transport/grpc:** check Compute Engine environment for DirectPath ([#781](https://www.github.com/googleapis/google-api-go-client/issues/781)) ([89287b6](https://www.github.com/googleapis/google-api-go-client/commit/89287b68a240f818e9ae70a6395b1d72e21ee236))

## [0.36.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.35.0...v0.36.0) (2020-12-03)


### Features

* **all:** auto-regenerate discovery clients , refs [#766](https://www.github.com/googleapis/google-api-go-client/issues/766) [#762](https://www.github.com/googleapis/google-api-go-client/issues/762) [#758](https://www.github.com/googleapis/google-api-go-client/issues/758) [#760](https://www.github.com/googleapis/google-api-go-client/issues/760) [#757](https://www.github.com/googleapis/google-api-go-client/issues/757) [#756](https://www.github.com/googleapis/google-api-go-client/issues/756) [#754](https://www.github.com/googleapis/google-api-go-client/issues/754) [#753](https://www.github.com/googleapis/google-api-go-client/issues/753) [#749](https://www.github.com/googleapis/google-api-go-client/issues/749) [#747](https://www.github.com/googleapis/google-api-go-client/issues/747) [#744](https://www.github.com/googleapis/google-api-go-client/issues/744)
* **internaloption:** add better support for self-signed JWT ([#738](https://www.github.com/googleapis/google-api-go-client/issues/738)) ([1a7550f](https://www.github.com/googleapis/google-api-go-client/commit/1a7550f9546052997806ff7ea9bcba55326bdb16))
* **transport:** Add default certificate caching support ([#721](https://www.github.com/googleapis/google-api-go-client/issues/721)) ([caa4d89](https://www.github.com/googleapis/google-api-go-client/commit/caa4d89fd452600f9911cfa0945500566cf9c72e))


### Bug Fixes

* **google-api-go-generator:** add patch for compute mtls endpoint ([#761](https://www.github.com/googleapis/google-api-go-client/issues/761)) ([445fe0b](https://www.github.com/googleapis/google-api-go-client/commit/445fe0be627de9769c5b252e77858c78682a6b8c))

## [0.35.0](https://www.github.com/googleapis/google-api-go-client/compare/v0.34.0...v0.35.0) (2020-11-06)


### Features

* **all:** auto-regenerate discovery clients , refs [#743](https://www.github.com/googleapis/google-api-go-client/issues/743) [#741](https://www.github.com/googleapis/google-api-go-client/issues/741) [#739](https://www.github.com/googleapis/google-api-go-client/issues/739) [#737](https://www.github.com/googleapis/google-api-go-client/issues/737) [#735](https://www.github.com/googleapis/google-api-go-client/issues/735) [#733](https://www.github.com/googleapis/google-api-go-client/issues/733) [#730](https://www.github.com/googleapis/google-api-go-client/issues/730) [#729](https://www.github.com/googleapis/google-api-go-client/issues/729) [#724](https://www.github.com/googleapis/google-api-go-client/issues/724)
* **internaloption:** add EnableDirectPath internaloption ([#732](https://www.github.com/googleapis/google-api-go-client/issues/732)) ([baf33b2](https://www.github.com/googleapis/google-api-go-client/commit/baf33b2baf0a1a5459e7b4ff193fa47117829169))

## v0.34.0

- transport:
  - Fix mergeEndpoint logic to support default endpoints without scheme.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.


## v0.33.0

- idtoken:
  - Add an example of setting HTTP auth header.
- internal:
  - Refactor service-account.json into a testdata folder.
- transport:
  - Add device certificate Authentication support to GRPC.
  - Support `GOOGLE_API_USE_CLIENT_CERTIFICATE` and
    `GOOGLE_API_USE_MTLS_ENDPOINT` environment variables to conform with
    [AIP-4114](https://google.aip.dev/auth/4114).
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.32.0

- option:
  - Add experimental ImpersonateCredentials option for impersonating a service
    account.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.31.0

- cloudcommerceprocurement:
  - Regenerate `cloudcommerceprocurement` v1.
- Updated dependencies.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.30.0

### Changes

- idtoken:
  - Fix flaky ecdsa test.
  - Fix some typos in the docs.
  - Fix `WithCredentialsJSON` not working with `NewClient`.
  - Speed up tests.
- internal:
  - Remove the install of staticcheck.
  - Automate dependency updates with Renovate.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.29.0

### Changes

- Various updates to autogenerated clients.
- transport: internal bug fixes for mTLS.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.28.0

### Changes

- gensupport:
  - Retry the initial request for a media upload in the storage library only.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.27.0

### Changes

- gensupport:
  - Expand retryable errors to include wrapped errors and transient network
    failures.
  - Add retry for the initial request in a resumable or multipart upload.
- transport/http:
  - Don't reuse a base transport between clients. This fixes a race condition in
    defaultBaseTransport.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.26.0

### Changes

- idtoken:
  - Populate Claims map.
- transport/http:
  - Update default HTTP transport settings to use a larger value for
    MaxIdleConnsPerHost. This improves performance in the storage client.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.25.0

### Announcements

[goolgeapis/google-api-go-client](https://github.com/googleapis/google-api-go-client)
has moved its source of truth to GitHub and is no longer a mirror. This means
that our contributing process has changed a bit. We will now be conducting all
code reviews on GitHub which means we now accept Pull Requests! If you have a
version of the codebase previously checked out you may wish to update your git
remote to point to GitHub.

### Changes

- all:
  - Updated instructions in CONTRIBUTING.md for pull requests.
- idtoken:
  - Validate now checks to see if the token is expired.
- sheets:
  - Update ExtendedValue Fields to be pointer types.
- support/bunder:
  - Fix a deadlock that could when handler limit was set to one.
- transport:
  - Allow `GOOGLE_API_USE_MTLS` overriding the mTLS endpoint behavior for the
    HTTP client.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.24.0

### Changes

- googleapi:
  - Return more details with errors.
- sqladmin
  - Make StorageAutoResize a pointer type for v1.
- transport/http:
  - When provided, use the TokenSource from options for NewTransport. This fixes
    a bug in idtoken.NewClient where the wrong TokenSource was being used for
    authentication.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.23.0

### Changes

- apigee:
  - Re-enable generation of this client.
- compute:
  - Make Id a on ExternalVpnGateway a pointer type.
- idtoken:
  - Add new package to support making requests with and validating Google ID
    tokens.
- slides:
  - Make int values of Range optional.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.22.0

### Depreciation Notice

- Package `google.golang.org/api/sql/v1beta4` has been deprecated as it was
  generated under the wrong name. This package will be removed in a future
  release. Please migrate to: `google.golang.org/api/sqladmin/v1beta4`.

### Changes

- Apigee client has temporarily been disabled.

- Updated custom search example to be in line with new API.

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.21.0

- Disabled automatic switching to *.mtls.googleapis.com endpoints.

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.20.0

- WithGRPCConnectionPool is a no-op for some APIs.

- correctly report Go version of runtime.

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.19.0

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.18.0

- Add the WithClientCertSource option for mTLS (client TLS certificates), currently only supported for HTTP clients.

- Allow host:port for endpoint overrides, rather than requiring the full base URL (for google.golang.org/api clients).

- Make DialPool work with WithGRPCConn plus non-zero pool size [googleapis/google-cloud-go#1780](https://github.com/googleapis/google-cloud-go/issues/1780)

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.17.0

- Revert sqladmin package name back from sql to sqladmin. (#448)

- Various updates to autogenerated clients.

Internal:

- transport/grpc: add internal WithDialPool option for GAPIC clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.16.0

- Increase the default chunk size for uploads (e.g., for the storage package) to 16 MB.

- transport:
  - Automatically populate QuotaProject from the "quota_project_id" field in the JSON credentials file.
  - Add grpc.DialPool, which opens multiple grpc.ClientConns based on WithGRPCConnectionPool option.

- Added a check to prevent mixed calls to Add and AddWait.

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.15.0

- monitoring/v3:
  - Rename Service to MService; revert APIService to Service.

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.14.0

- Fix for setting custom HTTP headers in the absence of UserAgent.

- Add a client option for disabling telemetry such as OpenCensus.

- Performance improvements to google.golang.org/api/support/bundler.

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.13.0

- Changes to how media path redirection is handled in generated code.

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.12.0

- Various updates to autogenerated clients.

## v0.11.0

- Various updates to autogenerated clients.

- Module information now indicates go 1.11 as oldest supported version.  As of
  October 1, 2019 versions 1.9 and 1.10 are no longer supported.

- Removed the following APIs which are no longer available via the discovery
  service: dfareporting/v2.8, prediction/*.

- The internal gensupport library has been relocated to the more idiomatic
  path internal/gensupport.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.10.0

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.9.0

- Small fix to chunking retry logic such that each chunk has its own retry
  deadline, instead of unbounded retries.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.8.0

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.7.0

- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.6.0

- Add support for GCP DirectPath.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.5.0

- Better support for google.api.HttpBody.
- Support for google.api.HttpBody in the healthcare API.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.4.0

- Includes a re-pin of opencensus, greatly reducing the transitive
dependency list.
- Deletes photoslibrary/v1. The photoslibrary team hopes to fully support Go in
the near future, but this autogenerated library is ready to be sunset. If you
rely on this client, please vendor this library at v0.3.2.
- Various updates to autogenerated clients.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.3.2

This patch releases re-builds the go.sum. This was not possible in the
previous release.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.3.1

This patch release removes github.com/golang/lint from the transitive
dependency list, resolving `go get -u` problems.

_Please note_: this release intentionally has a broken go.sum. Please use v0.3.2.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.3.0

go.mod modifications, including removal of go 1.12 statement and update of
opencensus dependency.

_Please note_: the release version is not indicative of an individual client's
stability or version.

## v0.2.0

General improvements.

_Please note:_ the release version is not indicative of an individual client's
stability or version.

## v0.1.0

Initial release along with Go module support.

_Please note:_ the release version is not indicative of an individual client's
stability or version.
